<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);	
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<?php
if(isset($_POST['nubmit']))
{
$zone=$info['zone'];
date_default_timezone_set(''.$zone.'');
$days = $_POST['days'];
$Date = date('Y-m-d'); 
$tanggal= date('Y-m-d H:i:s');
$tglsewa = date('Y-m-d H:i:s');
$tglkembali = date('Y-m-d', strtotime($Date. ' + '.$days.' days'));
$kodesewa = $_POST['kodesewa'];
$id_liburan = $_POST['id_liburan'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$id_liburan'"));
if($id_liburan == 0){
$diskon=0;
}else{
$diskon=$haka['diskon'];
}
$sem = $_POST['harga'];
$seko=$diskon/100;
$konn=$sem*$seko;

$harga=$sem-$konn;
$gogok = $_POST['gogok'];
$lam=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM customer WHERE ktp='$gogok'"));
$alamat = $lam['alamat'];
$ktp = $lam['ktp'];
$id_users = $lam['idcustomer'];
$namausers = $lam['namacust'];
$contact = $lam['contact'];
$email = $lam['email'];
$id_mitra = $_POST['id_mitra'];
$jaminan = $_POST['jaminan'];
$keterangan = $_POST['keterangan'];
	// email exist or not
	$query = "SELECT * FROM sewa WHERE kodesewa='$kodesewa' and status='active'";
	$result = mysqli_query($mysqli, $query);
	$count = mysqli_num_rows($result); // if email not found then register
	if($count == 0){
		mysqli_query($mysqli,"UPDATE `keranjang` SET `kodesewa`='$kodesewa' WHERE kodesewa='0';");
		mysqli_query($mysqli,"UPDATE `product` SET `status`='rented', kodesewa='$kodesewa', tglsewa='$tanggal', tglkembali='$tglkembali' WHERE kodesewa='book';");
		mysqli_query($mysqli,"INSERT INTO `customer` (`idcustomer`, `namacust`, `email`, `ktp`, `alamat`, `contact`, `picture`) VALUES (NULL, '$namausers', '$email', '$ktp', '$alamat', '$contact', '$picture');");
		if(mysqli_query($mysqli, "INSERT INTO `sewa` (`idsewa`, `tglsewa`, `tanggal`, `tglkembali`, `id_mitra`, `id_users`, `namausers`, `contact`, `alamat`, `ktp`, `jaminan`, `email`, `kodesewa`, `harga`, `status`, `diskon`, `hargadiskon`, `id_diskon`, `keterangan`) VALUES (NULL, '$tglsewa', '$tanggal', '$tglkembali', '$id_mitra', '$id_users', '$namausers', '$contact', '$alamat', '$ktp', '$jaminan', '$email', '$kodesewa', '$sem', 'active', '$diskon', '$harga', '$id_liburan', '$keterangan');"))

		{
			?>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
<div id="myModal" class="modal fade">
<div class="modal-dialog" style="margin-top: 100px;">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Data Already Saved</h4>
</div>
<div class="modal-body"><center>
<div align="center"><br>
<img src="success.gif"style="width:200px;height:auto;"></div>
<p style="color:#444;font-weight:bold">Invoice Code: <?php echo $kodesewa;?><br><small><?php echo $set['trans29']?></small></p>
<br>
<a target="_blank" href="printstruk.php?kodesewa=<?php echo $kodesewa;?>"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto;background: #09c;color: #fff;padding: 10px;border: none;"data-color="green"data-style="expand-right">Print Thermal Receipt</button>
</section>
</a>
<a target="_blank" href="print.php?kodesewa=<?php echo $kodesewa;?>"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto;background: green;color: #fff;padding: 10px;border: none;"data-color="green"data-style="expand-right">Print A4 Receipt</button>
</section>
</a>
<a onclick="javascript:showDiv()" href="index.php" class="btn btn-info btn-lg" style="width:90%;padding: 8px;background:linear-gradient(87deg,#ff5c2b 0,#af1515 100%)!important;font-size:14px;width: 90%;border:0;border-radius: 10px;color:#fff;">Input Again</a>
</center>
</div>
</div>
</div>
</div>
<?php
		}
		else
		{
			?><div style="color:#F0">Busy Server</div><?php
		}		
	}
	else{
			?>
<script>alert("Error, Please try Again");</script>
<script>document.location.href="index.php";</script><?php
	}
	
}
?>
<?php
if(isset($_POST['submit']))
{

$zone=$info['zone'];
date_default_timezone_set(''.$zone.'');
$days = $_POST['days'];
$Date = date('Y-m-d'); 
$tanggal= date('Y-m-d H:i:s');
$tglsewa = date('Y-m-d H:i:s');
$tglkembali = date('Y-m-d', strtotime($Date. ' + '.$days.' days'));

$kodesewa = $_POST['kodesewa'];
$id_liburan = $_POST['id_liburan'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$id_liburan'"));
if($id_liburan == 0){
$diskon=0;
}else{
$diskon=$haka['diskon'];
}
$sem = $_POST['harga'];
$seko=$diskon/100;
$konn=$sem*$seko;

$harga=$sem-$konn;

$alamat = $_POST['alamat'];
$ktp = $_POST['ktp'];
$id_mitra = $_POST['id_mitra'];
$namausers = $_POST['namausers'];
$contact = $_POST['contact'];
$jaminan = $_POST['jaminan'];
$email = $_POST['email'];
$keterangan = $_POST['keterangan'];
	// email exist or not
	$query = "SELECT * FROM sewa WHERE kodesewa='$kodesewa' and status='active'";
	$result = mysqli_query($mysqli, $query);
	$count = mysqli_num_rows($result); // if email not found then register
	
	if($count == 0){
		mysqli_query($mysqli,"UPDATE `keranjang` SET `kodesewa`='$kodesewa' WHERE kodesewa='0';");
		mysqli_query($mysqli,"UPDATE `product` SET `status`='rented', kodesewa='$kodesewa', tglsewa='$tanggal', tglkembali='$tglkembali' WHERE kodesewa='book';");
		mysqli_query($mysqli,"INSERT INTO `customer` (`idcustomer`, `namacust`, `email`, `ktp`, `alamat`, `contact`, `picture`) VALUES (NULL, '$namausers', '$email', '$ktp', '$alamat', '$contact', '$picture');");
		if(mysqli_query($mysqli, "INSERT INTO `sewa` (`idsewa`, `tglsewa`, `tanggal`, `tglkembali`, `id_mitra`, `id_users`, `namausers`, `contact`, `alamat`, `ktp`, `jaminan`, `email`, `kodesewa`, `harga`, `status`, `diskon`, `hargadiskon`, `id_diskon`, `keterangan`) VALUES (NULL, '$tglsewa', '$tanggal', '$tglkembali', '$id_mitra', '$id_users', '$namausers', '$contact', '$alamat', '$ktp', '$jaminan', '$email', '$kodesewa', '$sem', 'active', '$diskon', '$harga', '$id_liburan', '$keterangan');"))

		{
			?>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
<div id="myModal" class="modal fade">
<div class="modal-dialog" style="margin-top: 100px;">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Already Saved</h4>
</div>
<div class="modal-body"><center>
<div align="center"><br>
<img src="success.gif"style="width:200px;height:auto;"></div>
<p style="color:#444;font-weight:bold">Invoice Code: <?php echo $kodesewa;?><br><small><?php echo $set['trans29']?></small></p>
<br>
<a target="_blank" href="printstruk.php?kodesewa=<?php echo $kodesewa;?>"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto;background: #09c;color: #fff;padding: 10px;border: none;"data-color="green"data-style="expand-right">Print Thermal Receipt</button>
</section>
</a>
<a target="_blank" href="print.php?kodesewa=<?php echo $kodesewa;?>"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto;background: green;color: #fff;padding: 10px;border: none;"data-color="green"data-style="expand-right">Print Receipt on A4 Paper</button>
</section>
</a>
<a onclick="javascript:showDiv()" href="index.php" class="btn btn-info btn-lg" style="width:90%;padding: 8px;background:linear-gradient(87deg,#ff5c2b 0,#af1515 100%)!important;font-size:14px;width: 90%;border:0;border-radius: 10px;color:#fff;">Input Again</a>
</center>
</div>
</div>
</div>
</div>
<?php
		}
		else
		{
			?><div style="color:#F0">Busy Server</div><?php
		}		
	}
	else{
			?>
<script>alert("Error, Please try Again");</script>
<script>document.location.href="index.php";</script><?php
	}
	
}
?>
<!doctype html>
<html lang=en>
<head>
<style>#loading{position:fixed;left:0;right:0;z-index:99999;background-color:#ffffff7d;height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh}</style>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name=viewport />
<meta name=viewport content="width=device-width" />
<link href=../assets/css/bootstrap.min.css rel=stylesheet />
<link href=../assets/css/animate.min.css rel="stylesheet"/>
<link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
<link href=../assets/css/demo.css rel=stylesheet />
<link href=http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css rel=stylesheet>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel=stylesheet type=text/css>
<link href=../assets/css/pe-icon-7-stroke.css rel=stylesheet />
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js></script>
</head>
<style>div{pointer-events:auto;border:0;border-color:none}.div:hover{background-color:hsla(0,100%,100%,0.0);border:0;border-color:none}a:hover{text-decoration:none}.content{display:none}.preload{position:fixed;left:0;right:0;z-index:99999;background-color:#ffffff7d;height:100%;background-position:center;background-repeat:no-repeat;background-size:cover}</style>
<script>$(function(){$(".preload").fadeOut(100,function(){$(".content").fadeIn(200)})});</script>
<div class=preload><center><br><br><br><br><br><img style=margin-top:100px;width:60px src=../interwind.svg><br><br></center>
</div>
<body>
<br><br><br><br><br>
<div class=content>
<div class=container-fluid>
<div class=row>
<div class=col-md-8>
<div class=card>
<div class=header>
</div>
<div class=content>
<div class=form-section style=overflow:auto>
<center><small><?php echo $set['trans1']?></small></center>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js></script>
<?php include "../dbconnect.php";?>
<script type=text/javascript>$(document).ready(function(){$("#golek").keyup(function(){var a=$("#golek").val();if(a!=""){$("#jesil").html("<img width=300px src='loading.gif'/>");$.ajax({type:"post",url:"cari.php",data:"r="+a,success:function(b){$("#jesil").html(b)}})}})});</script>
<br><br><div style=padding:20px><input style="width:100%;border:1px solid #09c;padding:10px;border-radius:5px" autocomplete=off type=text name=golek id=golek class=form-control placeholder="<?php echo $set['trans2']?>"/>
<div style=width:100%;border:0;border-radius:40px;color:#796d6d id=jesil></div></div><br><br>
<center>
<link rel=stylesheet href=https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css integrity=sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u crossorigin=anonymous>
<style type=text/css>.tg{border-collapse:collapse;border-color:#ccc;border-spacing:0}.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:0;color:#333;font-family:Arial,sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal}.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:0;color:#333;font-family:Arial,sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal}.tg .tg-206d{background-color:#f9f9f9;font-family:"Lucida Sans Unicode","Lucida Grande",sans-serif!important;font-weight:bold;text-align:center;vertical-align:top}.tg .tg-td0d{font-family:"Lucida Sans Unicode","Lucida Grande",sans-serif!important;text-align:left;vertical-align:top}</style>
<table class=tg width=100%>
<thead>
<tr>
<th class=tg-td0d colspan=4><b style=color:#000><?php echo $set['trans6']?> : </b></th>
<th class=tg-td0d><a onclick=javascript:showDiv() href=resetsewa.php class="btn btn-info btn-lg" style="padding:3px;background:linear-gradient(87deg,#ff5c2b 0,#af1515 100%)!important;font-size:11px;width:100px;border:0;border-radius:20px;color:#fff"><?php echo $set['trans7']?></a></th>
</tr>
</thead>
<tbody>
<tr>
<td class=tg-206d><?php echo $set['trans8']?></td>
<td class=tg-206d><?php echo $set['trans9']?></td>
<td class=tg-206d><?php echo $set['trans10']?></td>
<td class=tg-206d><?php echo $set['trans11']?></td>
<td class=tg-206d><?php echo $set['trans12']?></td>
</tr>
<?php 
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as kor from keranjang where status='active' and kodesewa='0'"));
$aaaa = $nos['kor'];
$query = "SELECT * FROM keranjang where status='active' and kodesewa='0'";
$select = mysqli_query($mysqli,$query);
while ($result = mysqli_fetch_array($select)) {
$idproduct=$result['idproduct'];    
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$das = $row['hargasewa']; $fre = number_format($das,0,",",".");
$bias = $result['total']; $new = number_format($bias,0,",",".");
   ?>
<tr id=delete<?php echo $result['idkeranjang'] ?>>
<td>
<?php if (empty($row['picture'])) { ?>
<img src=../nopic.png style="width:100px"/>
<?php }else{ 
	if($row['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src=../fotobarang/<?php echo $row['picture'];?> style="width:100px"/>
<?php }}?></td>
<td style=float:left><?php echo $row['namaproduct']; ?><br><small><?php echo $set['trans13']?>: <?php echo $info['currency']; ?> <?php echo $fre; ?>/<?php echo $set['trans14']?></small></td>
<td><center><?php echo $result['qty']; ?></center></td>
<td><center><?php echo $info['currency']; ?>.<?php echo $new; ?></center></td>
<td><center><button onclick=deleteAjax(<?php echo $result['idkeranjang'];  ?>) class="btn btn-danger" style=background:none;border:none><img src=../delete.png width=25px></button></center></td>
</tr>
<?php } ?>
</tbody>
</table>

</div>
</div>

<center><?php echo $set['das31']?><br></center>
<style>.tab-wrap{border:1px solid #09c;padding:10px;-webkit-transition:.1s box-shadow ease;transition:.1s box-shadow ease;border-radius:6px;max-width:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;position:relative;list-style:none;background-color:#fff;margin:40px 0}.tab-wrap:hover{box-shadow:0 12px 23px rgba(0,0,0,0.23),0 10px 10px rgba(0,0,0,0.19)}.tab{display:none}.tab:checked:nth-of-type(1) ~ .tab-content:nth-of-type(1){opacity:1;-webkit-transition:.1s opacity ease-in,0.3s -webkit-transform ease;transition:.5s opacity ease-in,0.8s transform ease;position:relative;top:0;z-index:100;-webkit-transform:translateY(0px);-ms-transform:translateY(0px);transform:translateY(0px);text-shadow:0}.tab:checked:nth-of-type(2) ~ .tab-content:nth-of-type(2){opacity:1;-webkit-transition:.1s opacity ease-in,0.3s -webkit-transform ease;transition:.1s opacity ease-in,0.3s transform ease;position:relative;top:0;z-index:100;-webkit-transform:translateY(0px);-ms-transform:translateY(0px);transform:translateY(0px);text-shadow:0}.tab:checked:nth-of-type(3) ~ .tab-content:nth-of-type(3){opacity:1;-webkit-transition:.5s opacity ease-in,0.8s -webkit-transform ease;transition:.1s opacity ease-in,0.3s transform ease;position:relative;top:0;z-index:100;-webkit-transform:translateY(0px);-ms-transform:translateY(0px);transform:translateY(0px);text-shadow:0}.tab:checked:nth-of-type(4) ~ .tab-content:nth-of-type(4){opacity:1;-webkit-transition:.1s opacity ease-in,0.3s -webkit-transform ease;transition:.1s opacity ease-in,0.3s transform ease;position:relative;top:0;z-index:100;-webkit-transform:translateY(0px);-ms-transform:translateY(0px);transform:translateY(0px);text-shadow:0}.tab:checked:nth-of-type(5) ~ .tab-content:nth-of-type(5){opacity:1;-webkit-transition:.1s opacity ease-in,0.3s -webkit-transform ease;transition:.1s opacity ease-in,0.3s transform ease;position:relative;top:0;z-index:100;-webkit-transform:translateY(0px);-ms-transform:translateY(0px);transform:translateY(0px);text-shadow:0}.tab:first-of-type:not(:last-of-type)+label{border-top-right-radius:0;border-bottom-right-radius:0}.tab:not(:first-of-type):not(:last-of-type)+label{border-radius:0}.tab:last-of-type:not(:first-of-type)+label{border-top-left-radius:0;border-bottom-left-radius:0}.tab:checked+label{background-color:#fff;box-shadow:0 -1px 0 #fff inset;cursor:default}.tab:checked+label:hover{box-shadow:0 -1px 0 #fff inset;background-color:#fff}.tab+label{box-shadow:0 -1px 0 #eee inset;border-radius:6px 6px 0 0;cursor:pointer;display:block;text-decoration:none;color:#333;-webkit-box-flex:3;-webkit-flex-grow:3;-ms-flex-positive:3;flex-grow:3;text-align:center;background-color:#f2f2f2;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;text-align:center;-webkit-transition:.3s background-color ease,0.3s box-shadow ease;transition:.3s background-color ease,0.3s box-shadow ease;height:50px;box-sizing:border-box;padding:15px}.tab+label:hover{background-color:#f9f9f9;box-shadow:0 1px 0 #f4f4f4 inset}.tab-content{padding:10px 25px;background-color:transparent;position:absolute;width:100%;z-index:-1;opacity:0;left:0;-webkit-transform:translateY(-3px);-ms-transform:translateY(-3px);transform:translateY(-3px);border-radius:6px}body{font-family:'roboto',sans-serif;background-color:#e7e7e7;color:#777}.container{margin:0 auto;display:block;max-width:800px}.container>*:not(.tab-wrap){padding:0 80px}h1,h2{margin:0;color:#444;text-align:center}h2{font-size:1em;margin-bottom:30px}h1{margin-top:150px}p{line-height:1.6;margin-bottom:20px}</style>
<div class="tab-wrap">
<input type="radio" id="tab1" name="tabGroup1" class="tab" checked>
<label for="tab1"><?php echo $set['trans15']?></label>
<input type="radio" id="tab2" name="tabGroup1" class="tab">
<label for="tab2"><?php echo $set['trans16']?></label>
<div class="tab-content">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
<center><?php echo $set['trans17']?></center>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js></script>
<?php include "../dbconnect.php";?>
<script type=text/javascript>$(document).ready(function(){$("#gogok").keyup(function(){var a=$("#gogok").val();if(a!=""){$("#hasil").html("<img width=300px src='loading.gif'/>");$.ajax({type:"post",url:"member.php",data:"r="+a,success:function(b){$("#hasil").html(b)}})}})});</script>
<br><br><div style=padding:10px><input style="width:100%;border:1px solid #09c;padding:10px;border-radius:5px" autocomplete=off type=text name=gogok id=gogok class=form-control placeholder="<?php echo $set['trans18']?>"/>
<div style=width:100%;border:0;border-radius:40px;color:#796d6d id=hasil></div></div><br><br>

<?php 
$jam=mysqli_fetch_array(mysqli_query($mysqli, "SELECT MAX(qty)as bone FROM keranjang WHERE kodesewa='0'"));
$days=$jam['bone'];

?>
<input type="hidden" name="days" value="<?php echo $days;?>" />
<input type="hidden" name="id_mitra" value="<?php echo $_SESSION['mitra'];?>" />
<input type="hidden" name="harga" value="<?php echo $aaaa;?>" />
<input type="hidden" name="kodesewa" value="<?php
function git(){
$gas=NULL;
$n = 6; // jumlah karakter yang akan di bentuk.
$chr = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gas .=substr($chr,$rIdx,1);
}return $gas;};echo git();?>" />
<img id="blah" style="width:100%;height:auto" />
Select Discount
 <select class="form-control" style="border:1px solid #09c;border-radius:25px;width:100%" name="id_liburan" required="required"> 
            <option style="color:grey" name="id_liburan" value="0" >No Discount</option>
	    <?php
		$ash=mysqli_query($mysqli, "SELECT * FROM liburnasional");
            while($lim = mysqli_fetch_assoc($ash))
            {
            ?>
            <option name="id_liburan" style="color:grey" value="<?php echo $lim['id_liburan'];?>" ><?php echo $lim['keterangan_liburan']; ?> (Discount <?php echo $lim['diskon']; ?>%)</option>
            <?php
            }               
        ?>
		</select><br>
<input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text placeholder="<?php echo $set['trans19']?>" name="jaminan"required=required/><br><br>
<textarea style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number placeholder="Details/Notes" name="keterangan"></textarea><br>
<button type=submit name=nubmit style=border-radius:20px;color:#fff;background-color:#09c;padding:10px;z-index:9999;width:100%;border:none data-color=blue><?php echo $set['trans28']?><br></button><br><br>
<script type=text/javascript>function deleteAjax(a){$.ajax({type:"post",url:"deletecart.php",data:{delete_id:a},success:function(b){$("#delete"+a).hide("fast")}})}</script>
<script src=https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js></script>
</center>
</form>
</div>
<div class="tab-content">
<center><?php echo $set['trans20']?></center><br>
 <script>
        function onlyAlphabet(evt) {
            var theEvent = evt || window.event;
            var key = theEvent.keyCode || theEvent.which;

            var keychar = String.fromCharCode(key);
            var keycheck = /[a-zA-z\s]/;

            if (!(key == 8 || key == 27 || key == 46 || key == 9 || key == 39 || key == 94)) // backspace delete  escape arrows
            {
               
                    if (!keycheck.test(keychar)) {
                        theEvent.returnValue = false;//for IE
                        if (theEvent.preventDefault)
                            theEvent.preventDefault();//Firefox
                    }
                
                
            }
            else if(key==94)
                theEvent.preventDefault();
        }
    </script>
<form id="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">


<table width=100%>
<tr>
<td width=15% style=padding:10px><?php echo $set['trans21']?></td>
<td width=2% style=padding:10px>:</td>
<td width=83% style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number placeholder="ID Nationality" name="ktp"required=required></td>
</tr><tr>
<td style=padding:10px><?php echo $set['trans22']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%" id="Text1" type="text"  onkeypress="return onlyAlphabet(event)" placeholder="Name Renter" name="namausers"required=required></td>
</tr>
<tr>
<td style=padding:10px><?php echo $set['trans23']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text placeholder="Address" name="alamat"required=required></td>
</tr>
<tr>
<td style=padding:10px><?php echo $set['trans24']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text placeholder="Email" name="email"required=required></td>
</tr>
<tr>
<td style=padding:10px><?php echo $set['trans25']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text placeholder="<?php echo $set['trans19']?>" name="jaminan"required=required></td>
</tr>
<tr>
<td style=padding:10px><?php echo $set['trans26']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number placeholder="Phone" name="contact"required=required></td>
</tr>
<tr>
<td style=padding:10px><?php echo $set['trans27']?></td>
<td style=padding:10px>:</td>
<td style=padding:10px><textarea style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number placeholder="Add Notes" name="keterangan"></textarea></td>
</tr>
</table>
<?php 
$jam=mysqli_fetch_array(mysqli_query($mysqli, "SELECT MAX(qty)as bone FROM keranjang WHERE kodesewa='0'"));
$days=$jam['bone'];

?>
<input type="hidden" name="id_mitra" value="<?php echo $_SESSION['mitra'];?>" />
<input type="hidden" name="days" value="<?php echo $days;?>" />
<input type="hidden" name="harga" value="<?php echo $aaaa;?>" />
<input type="hidden" name="kodesewa" value="<?php
function resi(){
$gpass=NULL;
$n = 6; // jumlah karakter yang akan di bentuk.
$chr = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}return $gpass;};echo resi();?>" />
<img id="blah" style="width:100%;height:auto" />
Select Discount
 <select class="form-control" style="border:1px solid #09c;border-radius:25px;width:100%" name="id_liburan" required="required"> 
            <option style="color:grey" name="id_liburan" value="0" >No Discount</option>
	    <?php
		$get=mysqli_query($mysqli, "SELECT * FROM liburnasional");
            while($jim = mysqli_fetch_assoc($get))
            {
            ?>
            <option name="id_liburan" style="color:grey" value="<?php echo $jim['id_liburan'];?>" ><?php echo $jim['keterangan_liburan']; ?> (Discount <?php echo $jim['diskon']; ?>%)</option>
            <?php
            }               
        ?>
		</select><br>
		
<button type=submit name=submit style=border-radius:20px;color:#fff;background-color:#09c;padding:10px;z-index:9999;width:100%;border:none data-color=blue><?php echo $set['trans28']?><br></button><br><br>
<script type=text/javascript>function deleteAjax(a){$.ajax({type:"post",url:"deletecart.php",data:{delete_id:a},success:function(b){$("#delete"+a).hide("fast")}})}</script>
<script src=https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js></script>
</center>
</form>
</div>
</div>
</div>

</div>
<div class=col-md-4>
<div class="card card-user" style=padding:0;margin:0><br><center>
<img src=../logostreet.png style=margin:0;width:100%;height:auto alt="..."/><br><small style=font-size:10px;color:#444>
<?php echo $info['namaapp']?> -
<?php echo $info['address']?> <br><?php echo $info['city']?>, <?php echo $info['country']?>. <?php echo $info['poscode']?> - Phone <?php echo $info['phone']?>
</center></small>
<div class=content style=padding:0;margin:0>
<center>
<script type=text/javascript>$(document).ready(function(){goadData()});var goadData=function(){$.ajax({type:"GET",url:"betuser.php",dataType:"html",success:function(a){$("#nesponsecontainer").html(a);setTimeout(goadData,1000)}})};</script>
<div id=nesponsecontainer align=center></div>
</center>
</div>
<hr>
<div class=text-center>
<small><?php echo $info['thanks']?></small><br>
<?php echo $info['slogan']?>
</div>
</div>
</div>
<script>
function submitFormsWithCtrlEnter() {
  $('form').keydown(function(event) {
    if (event.ctrlKey && event.keyCode === 13) {
      $(this).trigger('submit');
    }
  })
}
</script>
</div>
</div>
</div>
</body>
<script src=../assets/js/jquery.3.2.1.min.js type=text/javascript></script>
<script src=../assets/js/bootstrap.min.js type=text/javascript></script>
<script src=../assets/js/chartist.min.js></script>
<script src=../assets/js/bootstrap-notify.js></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>
<script src=../assets/js/demo.js></script>
</html>
<div id=loading style=display:none><center><br><br><br><img style=margin-top:100px;width:60px src=../interwind.svg><br><br></center>
</div>
<script type=text/javascript>function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>