<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$idcustomer = $_GET['idcustomer'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from customer where idcustomer='$idcustomer'"));

if(isset($_POST['submit']))
{
$alamat = $_POST['alamat'];
$ktp = $_POST['ktp'];
$idcustomer = $_POST['idcustomer'];
$namausers = $_POST['namacust'];
$contact = $_POST['contact'];
$email = $_POST['email'];
	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['sicture'];
	}else{
		$picture=$_FILES['picture']['name'];
		//definisikan variabel file dan kendaraan file
		$uploaddir='../foto_mitra/';
		$kendaraanfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['picture']['tmp_name'],$kendaraanfile);
	}
	
$query=mysqli_query($mysqli, "UPDATE `customer` SET `alamat` = '$alamat', `ktp` = '$ktp', `contact` = '$contact', `email` = '$email', `namacust` = '$namausers', `picture` = '$picture' WHERE `customer`.`idcustomer` = '$idcustomer';");
if($query){
		?>
	<center><script>document.location.href="customer.php";</script>
</center>
		<?php
	}else{
		echo mysql_query();
	}

}else{
	unset($_POST['submit']);
}
?>
	<meta charset="utf-8" />
	<html>
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body style="padding:25px;"><center>
<div class="wrapper">
 
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
						<a href="customer.php" style="position:relative;left:0;float: left;color:red" onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Kembali</i></a><br>
                                <h4 class="title">Update Data Customer</h4>
                              </div><br><br>
                            <div class="content table-responsive table-full-width">
                                <form id="form"action="updatecustomer.php" enctype="multipart/form-data"  method="post" name="postform">
<table width=100%>
<tr>
<td width=15% style=padding:10px>Profile Picture</td>
<td width=2% style=padding:10px>:</td>
<td width=83% style=padding:10px><input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="file" name="picture" size="999999" required >
<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="hidden" name="sicture" value="<?php echo $row['picture'];?>">
</td>
</tr><tr>
<tr>
<td width=15% style=padding:10px>No. KTP</td>
<td width=2% style=padding:10px>:</td>
<td width=83% style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number value="<?php echo $row['ktp'];?>" name="ktp"required=required></td>
</tr><tr>
<td style=padding:10px>Atas Nama</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['namacust'];?>" name="namausers"required=required></td>
</tr>
<tr>
<td style=padding:10px>Alamat</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['alamat'];?>" name="alamat"required=required></td>
</tr>
<tr>
<td style=padding:10px>Email</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['email'];?>" name="email"required=required></td>
</tr>
<tr>
<td style=padding:10px>Nomor Handphone</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number value="<?php echo $row['contact'];?>" name="contact"required=required></td>
</tr>

</table>
<input type="hidden" name="idcustomer" value="<?php echo $_GET['idcustomer'];?>" />
<center>
<button type="submit" name="submit" class="btn btn-info btn-lg" style="background-color:#09c;color:#fff;z-index:9999;width:80%;height:70px" data-color="blue">Simpan<br></button><br>
</center>
<br><br><br>
	</form>
                            </div>
                        </div>
                    </div>


                 

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <?php echo $info['namaapp'];?>
                </p>
            </div>
        </footer>


</div>
</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo puUSD se -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</center>

</html>
