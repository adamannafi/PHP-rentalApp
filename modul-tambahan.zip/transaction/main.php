<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">
<link rel="stylesheet"type="text/css"href="../button.css"/>

</head>
<body style="font-family:monospace;">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background:linear-gradient(87deg, #ffb7b3 0, #fffbc5 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5" >
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>

<center><h4><b><?php echo $set['sewa1']?>
</b></h4><?php echo $set['sewa2']?> </center>
                <div class="col text-right">
				<a target="_blank"href="sewa.php" style="background:#b10a0a;color:#fff" class="btn btn-sm btn-primary">Print PDF</a>
                <a target="_blank"href="sewa1export.php" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Print Excel</a>
                </div><br>

<p>

            <div class="table-responsive">
              <!-- Projects table -->
			  	
                            <div class="content table-responsive table-full-width">

 <style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>	
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
  <tr>
    <th class="tg-0lax">No</th>
    <th class="tg-0lax"><?php echo $set['sewa3']?></th>
    <th class="tg-0lax"><?php echo $set['sewa4']?></th>
    <th class="tg-0lax"><?php echo $set['sewa5']?></th>
    <th class="tg-0lax">Discount</th>
    <th class="tg-0lax">Discount Price</th>
    <th class="tg-0lax">Status</th>
    <th class="tg-0lax">Navigation</th>
  </tr>
</thead>
<tbody>
<?php 
$result = mysqli_query($mysqli, "SELECT * FROM `sewa` ORDER by idsewa DESC");
$i = 1;
while($res = mysqli_fetch_array($result)) { 	
$id_mitra=$res['id_mitra'];
$bin=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra='$id_mitra'");
$jas=mysqli_fetch_array($bin);
echo "<tr>";?>
<td width="2%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php
		echo"<td width=5%>".$set['fin6'].": ".$res['kodesewa']."<br>Date rent: ".$res['tanggal']."<br>Date Return: ".$res['tglkembali']."<br>Admin: ".$jas['nama_mitra']."</td>";
		echo"<td width=5%>Customer: ".$res['namausers']."<br>".$set['trans21'].": ".$res['ktp']."<br>".$set['trans23'].": ".$res['alamat']."<br>".$set['trans26'].": ".$res['contact']."<br>".$set['trans24'].": ".$res['email']."<br>".$set['trans25'].": ".$res['jaminan']."</td>";
		$jika = $res['harga']; $revenue = number_format($jika,0,",",".");
		echo"<td width=5%> ".$info['currency']."".$revenue.",-</td>";
		echo"<td width=5%>".$res['diskon']."%</td>";
		$kikas = $res['hargadiskon']; $jenee = number_format($kikas,0,",",".");
		echo"<td width=5%>".$info['currency']." ".$jenee.",-</td>";
		echo"<td width=5%>".$res['status']."</td>";
echo "<td>";
	if($rows['sebagai']=='superuser')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='pm')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='am')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
echo "<a href=\"printstruk.php?kodesewa=$res[kodesewa]\" target=_blank onClick=\"return confirm('Print receipt to thermal printer?')\"><img src=../print.png width=25px/></a>";			
echo "<a style=padding:5px href=\"print.php?kodesewa=$res[kodesewa]\" target=_blank onClick=\"return confirm('Print receipt to paper A4?')\"><img src=../print.png width=25px/><b style=margin-left:-10px>A4</b></a>";			

echo "</td>";	
		
		echo "</tr>";	
		
	}
	?>
                                    </tbody>
                                </table>
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-color:#ccc;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#ccc;color:#333;background-color:#fff;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#ccc;color:#333;background-color:#f0f0f0;}
.tg .tg-4p94{color:#656565;text-align:center;vertical-align:top}
.tg .tg-oeta{background-color:#f9f9f9;font-weight:bold;font-size:12px;color:#656565;text-align:center;vertical-align:top}
.tg .tg-7wzs{color:#656565;text-align:center;vertical-align:middle}
.tg .tg-ltiz{background-color:#f9f9f9;font-size:12px;color:#656565;text-align:left;vertical-align:middle}
.tg .tg-wix3{background-color:#f9f9f9;color:#656565;text-align:center;vertical-align:top}
</style>
<table width="100%" style="padding:30px;" class="tg">
<tr>
<th class="tg-7wzs" colspan="5"><span style="font-weight:bold"><?php echo $set['sewa6']?></span></th>
</tr>
<tr>
<td class="tg-ltiz" colspan="2"><span style="font-weight:normal"><?php echo $set['sewa9']?></span><br><span style="font-weight:bold"><?php echo $set['sewa10']?> <?php echo date('Y');?> etc.</span><span style="font-weight:bold">Then Click print.</span></td>
<td class="tg-oeta" colspan="2"><?php echo $set['sewa7']?><br><br>
<form id="form"action="cetakcari.php"method="post"><center>
<input class="form-control" width="60%" placeholder="date..." type="date" value="<?php echo date('d-m-Y');?>" name="from_date" required="required"><br>
</center><br>
</td>
<td class="tg-oeta" colspan="2"><?php echo $set['sewa8']?><br><br><center>
<input class="form-control" width="60%" placeholder="date..." type="date" value="<?php echo date('d-m-Y');?>" name="to_date" required="required"><br>
</center><br>
<center><section class="button-demo"><button type="submit"name="tambah" style="border: 1px solid #09c; width: 60%; padding: 10px; color: #333; background: rgb(236 236 236); background: linear-gradient(63deg, rgb(226 226 226) 0%, rgb(239 239 239) 100%); border-radius: 20px; }" ><img src="../print.png" width="30px"/> <b>Print</b></button></section>
</center>
</form>
	</td>
  </tr>
</table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
			</div></p>
	    </div>

  </div>
  

</div>

        </div>
      </div>



	  
<script>
function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-border-red", "London");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.firstElementChild.className += " w3-border-red";
}
</script>

      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> <?php echo $info['namaapp']?>
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>