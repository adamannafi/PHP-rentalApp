<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
?><br>
<center style="color:#444">Nice Try to crack dude!! ;)<br>Your Session is Expired, please Login from Admin App</center>
<?php } else{?>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" />
<body style="background-color:#fff;padding:15px;font-family:Segoe UI" onload="window.print()">
<p style="color:#444;padding:15px">
<center><h4><b>Data Mutasi Tagihan Pembayaran
</b></h4>Keseluruhan Mutasi Pembayaran</center>
<br><br>
<style>
td.productsTable
{
    border: 1px dotted #999999;
}

.productsTable td
{
    border: 1px dotted #999999;
}

.productsTable th
{
    border: 2px dashed #444;
}
</style>
	<table class="productsTable" cellpadding="10" style="font-size:12px;" id="dataTable" width="100%" cellspacing="2">
                                    <thead><tr>
<th>No</th>
		<th>Tgl Mutasi</th>
		<th>Atas Nama</th>
		<th>Nilai</th>
		<th>Jenis Mutasi</th>
		<th>Kode Temuan</th>
	<?php 
$result = mysqli_query($mysqli, "SELECT * FROM mutasi ORDER BY tglmutasi DESC");
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td>
<?php	
echo "<td>".$res['tglmutasi']."</td>";
echo "<td>".$res['atasnama']."</td>";
echo "<td>".$res['nilai']."</td>";
echo "<td>".$res['tipemutasi']."</td>";
echo "<td>".$res['kodetemuan']."</td>";
	}
	?>
	</table>
		<br><br>

</p>
    <link href="../dash/assets/bootstrap.min.css" rel="stylesheet">
    <link href="../dash/assets/datatables.bootstrap4.min.css" rel="stylesheet">
    <!-- Bootstrap core JavaScript-->
    <script src="../dash/assets/jquery.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="../dash/assets/jquery.datatables.min.js"></script>
    <script src="../dash/assets/datatables.bootstrap4.min.js"></script>
 <br><br><br>
<center>Copyright @i-Base</center>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>
<div id="editor"></div>
</body>
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>
<?php }?>