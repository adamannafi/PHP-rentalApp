<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<?php 
session_start();
include "../dbconnect.php";
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
if(!isset($_SESSION['mitra']))
{?>
<script>alert("Login Session Expired, Please login again");</script>
<?php }?>
<style>#loading{position:fixed;left:0;right:0;z-index:99999;background-color:#ffffff7d;height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh}</style>
<?php
include "../dbconnect.php";
if(isset($_POST['send']))
{
$created=date('d-m-Y h:i:s');
$kodesewa = $_POST['kodesewa'];
	// email exist or not
	$query = "SELECT * FROM sewa WHERE kodesewa='$kodesewa' and status='active'";
	$result = mysqli_query($mysqli, $query);
	$count = mysqli_num_rows($result); // if email not found then register
	
	if($count == 1){
mysqli_query($mysqli,"UPDATE `product` SET `status`='available', kodesewa='0' WHERE kodesewa='$kodesewa';");
mysqli_query($mysqli,"UPDATE `keranjang` SET `status`='finish' WHERE kodesewa='$kodesewa';");
if(mysqli_query($mysqli, "UPDATE `sewa` SET `status`='finish' WHERE kodesewa='$kodesewa';"))
		{
			?>
<script>document.location.href="kembali.php";</script>
<?php
		}
		else
		{
			?><div style="color:#F0">Busy Server</div><?php
		}		
	}
	else{
			?>
<script>alert("Not found");</script>
<script>document.location.href="kembali.php";</script><?php
	}
	
}
?>
<?php
$r=$_POST['r'];
$kuu=mysqli_query($mysqli, "select * from sewa where namausers like '%".$r."%' or kodesewa like '%".$r."%' or ktp like '%".$r."%' or contact like '%".$r."%' or hargadiskon like '%".$r."%' LIMIT 4");
$row=mysqli_num_rows($kuu);
if ($row > 0) // jika baris lebih dari 0 / data ditemukan
{
	while ($data=mysqli_fetch_array($kuu)) // perulangna untuk menampilkan data
	{
$som=$data['id_diskon'];
if($som == 0){
$bias = $data['harga']; $new = number_format($bias,0,",",".");
}else{
$bias = $data['hargadiskon']; $new = number_format($bias,0,",",".");
}
$sewa=$data['status']; if($sewa=='finish'){}else{
		// menampilkan data dalam bentuk table
		echo "<table width='100%' style='font-family:monospace;color:#000;border-bottom:1px solid #d4d4d4;font-size:14px;padding:4px;'>
<thead>
  <tr> 
    <th width=46%><b><div style='color:#09c;font-size:13px;text-align:left'>INVOICE : ".$data['kodesewa']."</small></div></b><br>".$data['namausers']." - ".$data['contact']."</th>
    <th width=25% style='text-align:left;font-size:12px'>".$info['currency']." ".$new.",-</th>";?>
<th width="29%" style=""><?php echo $set['fin8']?>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="idproduct" value="<?php echo $data['idproduct'];?>"/>
<input type="hidden" name="hrg" value="<?php echo $data['hargasewa'];?>"/>
<input type="hidden" name="id_mitra" value="<?php echo $_SESSION['mitra'];?>"/>
<input type="hidden" name="kodesewa" value="<?php echo $data['kodesewa'];?>"/>
<input style="padding:3px;border-radius:8px;border:0;width:100%;background:linear-gradient(87deg,#49eca1 0,#5b966d 100%)!important;color:#fff" onclick="javascript:showDiv()" type="submit" value="<?php echo $set['fin9']?>" name="send" /></form>
</th>
<?php echo "</tr>
</thead>
</table>";	
$kodesewa=$data['kodesewa'];
?>
<style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
</style>
<table class=tg width=100%>
<thead>
  <tr>
    <th class="tg-amwm"><?php echo $set['trans8']?></th>
    <th class="tg-amwm"><?php echo $set['trans9']?></th>
    <th class="tg-amwm"><?php echo $set['trans10']?></th>
    <th class="tg-amwm"><?php echo $set['trans11']?></th>
  </tr>
</thead>
<?php 
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as kor from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['kor']; $mew = number_format($aaaa,0,",",".");
$query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";
$select = mysqli_query($mysqli,$query);
while ($result = mysqli_fetch_array($select)) {
$idproduct=$result['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$das = $soq['hargasewa']; $fre = number_format($das,0,",",".");
$bias = $result['total']; $new = number_format($bias,0,",",".");


$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$bias*$sidis;
$bingas = $bias-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td>
<?php if (empty($soq['picture'])) { ?>
<img src=../nopic.png style="width:100px"/>
<?php }else{ 
	if($soq['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src=../fotobarang/<?php echo $soq['picture'];?> style="width:100px"/>
<?php }}?></td>
<td ><?php echo $soq['namaproduct']; ?><br><small><?php echo $set['trans13']?>: <?php echo $info['currency']?> <?php echo $fre; ?>/<?php echo $set['trans14']?></small></td>
<td><center><?php echo $result['qty']; ?> <?php echo $set['trans10']?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td><center>Rp.<?php echo $new; ?></center></td>
<?php }else{ ?>
<td><center>Rp.<?php echo $jen; ?></center></td>
	<?php }?>
</tr>
<?php } ?>
<tr>
<?php if($som == 0){?>
<td style="border:none;" >&nbsp;</td>
	<?php }else{ ?>
<td style="border:none;" >Discount <?php echo $haka['keterangan_liburan']; ?> <?php echo $haka['diskon']; ?>%</td>	
	<?php }?>
<td style="border:none;"><b style="float:right">TOTAL</b></td>

<td width="3%" style="border:none;" ><center>:</center></td>
<?php if($som == 0){?>
<td style="border:none;"><center><?php echo $info['currency']?> <?php echo $mew; ?>,-</center></td>
	<?php }else{ ?>
<td style="border:none;"><center><?php echo $info['currency']?> <?php echo $kem; ?>,-</center></td>
	<?php }?>
</tr>
</tbody>
</table>
<?php
	}}
}
else // jika data tidak ditemukan
{
	echo "<br><br><center><strong>Data not Found</strong></center>";	
}
?>
<div id="loading" style="display:none"><center><br><br><br><img style="margin-top:100px;width:60px" src="../interwind.svg"><br><br></center>
</div>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>