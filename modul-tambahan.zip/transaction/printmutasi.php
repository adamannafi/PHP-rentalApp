	<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);

$idmutasi = $_GET['idmutasi'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from mutasi where idmutasi='$idmutasi'"));

?>
<meta charset="utf-8" />
	<html>
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body style="padding:25px;" style="font-family:monospace" onload="window.print()"><center>
<div class="wrapper">
 
        <div class="content">
            <div class="container-fluid">
			<br><br><br><br><br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
						<a href="main.php" style="float:left;color:#444"onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Back</i></a><br>
						     <h4 class="title">Mutasi No LHP: <?php echo $row['nolhp'];?> <?php echo $row['tglmutasi'];?> </h4>
                              </div><br><br>
                            <div class="content table-responsive table-full-width">
                  
<style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:monospace;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:monospace;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-c3ow{border-color:inherit;text-align:center;vertical-align:top}
.tg .tg-7btt{border-color:inherit;font-weight:bold;text-align:center;vertical-align:top}
.tg .tg-btxf{background-color:#f9f9f9;border-color:inherit;text-align:left;vertical-align:top}
.tg .tg-dvpl{border-color:inherit;text-align:right;vertical-align:top}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
</style>
<table class="tg" width="100%">
<thead>
  <tr>
    <th class="tg-7btt">No. LHP</th>
    <th class="tg-7btt">KODE TEMUAN</th>
    <th class="tg-7btt">KETERANGAN MUTASI</th>
    <th class="tg-7btt">NILAI</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-c3ow"><?php echo $row['nolhp'];?></td>
    <td class="tg-c3ow"><?php echo $row['kodetemuan'];?></td>
    <td class="tg-btxf">Atas Nama: <?php echo $row['atasnama'];?> <br>Tahun Instansi: <?php echo $row['instansi'];?><br>Tanggal: <?php echo $row['tglmutasi'];?><br><br>Lihat Bukti Pembayaran:<br><img src="../foto_mitra/<?php echo $row['buktidokumen'];?>" width="850px" height="auto"/></td>
    <td class="tg-dvpl"><b><?php $num_rows=$row['nilai']; $perawat = number_format($num_rows,0,",","."); echo $perawat;?></b></td>
  </tr>
</tbody>
</table>
                            </div>
                        </div>
                    </div>


                 

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> iBase
                </p>
            </div>
        </footer>


</div>
</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo puUSD se -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</center>

</html>
