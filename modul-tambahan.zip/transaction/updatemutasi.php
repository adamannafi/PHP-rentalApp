<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);


$idpantau = $_GET['idpantau'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from pantau where idpantau='$idpantau'"));
?>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">

</head>
<body style="font-family:monospace;font-size:12px">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background: linear-gradient(87deg, #b9dce4 0, #9fecff 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5">
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>
						<a href="index.php" onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Back</i></a><br>
<center><h4><b>Pembayaran Temuan LHP

<p>

            <div class="table-responsive">
              <!-- Projects table -->
           
<div class="form-section" style="overflow:auto">
	<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
                                    <thead><tr>
	<th width="5%">No</th>
		<th width="10%">NO LHP,<br>OPD<br>Tanggal</th>
		<th width="15%">NILAI TEMUAN, KODE TEMUAN,<br> JUDUL TEMUAN, <br>TAHUN ANGGARAN<br>& TAHUN AUDIT</th>
		<th width="15%">REKOMENDASI,<br> PENANGGUNGJAWAB TEMUAN<br>& JABATAN</th>
	</tr></thead>
	<?php 
$idpantau = $_GET['idpantau'];
$result = mysqli_query($mysqli, "SELECT * FROM pantau where idpantau='$idpantau'");
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php	
echo "<td width='20%'>".$res['nolhp']."<br>".$res['opd']."<br>Tanggal: ".$res['tglpiutang']."<br><br>";?>  
<?php echo "<br><br></td>";
$num_rows=$res['nilaipiutang'];
$perawat = number_format($num_rows,0,",",".");
echo "<td width='20%' style='white-space: normal;'><b>Nilai: Rp.".$perawat."<br></b>Kode temuan: ".$res['kodetemuan']."<br>Judul:<br>".$res['judultemuan']."<br>Tahun Anggaran: ".$res['thn_anggran']."<br>Tahun Temuan: ".$res['thn_audit']."</td>";
echo "<td width='20%' style='white-space: normal;'>Rekomendasi: ".$res['rekom']."<br>Penanggung Jawab: ".$res['penanggungjwb']."<br>Jabatan: ".$res['jabatan']."</td>";
	}
	?>
	</table>
<form class="bemo-form" action="mutasisubmited.php" method="POST">
<center><h4><small><b>Input Pembayaran</b><br><small>Isi Formulir Laporan Temuan lalu klik submit</small></small></h4></center><br>
<label><small style="float:left">Tanggal Pembayaran</small></label><br>
<input class="form-control" value="<?php echo date('d-m-Y h:i:s');?>" type="date" name="tglmutasi"><br>
<input class="form-control" value="<?php echo $row['kodetemuan'];?>" type="hidden" name="kodetemuan" >
<input class="form-control" value="<?php echo date('d-m-Y h:i:s');?>" type="hidden" name="tglmutasi" >
<label><small style="float:left">Kode Temuan</small></label><br>
<input class="form-control" value="<?php echo $row['kodetemuan'];?>" type="text" name="kodetemuan" disabled><br>
<label><small style="float:left">Nilai Pembayaran</small></label><br>
<input class="form-control" placeholder="masukkan nilai format angka dalam rupiah" type="number" name="nilai" required><br>
<label><small style="float:left">Atas nama</small></label><br>
<input class="form-control" placeholder="Nama penanggung Jawab/Pembayaran" type="text" name="atasnama" required="required"><br>
<label><small style="float:left">Instansi</small></label><br>
<input class="form-control" placeholder="Nama instansi sehubungan penanggung jawab" type="text" name="instansi" required="required"><br>
<label><small style="float:left">Tipe Pembayaran</small></label><br>
<select class="form-control" name="status" required>
  <option name="status" value="CASH">CASH</option>
  <option name="status" value="TRANSFER">TRANSFER</option>
</select><br> 
<label><small style="float:left">Upload Dokumen Bukti Pembayaran</small></label><br>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.0/jquery.min.js"></script>
<link class="jsbin" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />
<script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
<small>(File format for upload is JPG picture, PNG, GIF)</small><br>
  <input name="dokumen" id="fileInput" type='file' data-max-size="20489999" class="upload-file" onchange="readURL(this);" /><br>
    <img id="blah" src="camera.png" alt="your image" />
<input type="hidden" name="id_mitra" value="<?php echo $_SESSION['mitra']; ?>"/>
<input type="hidden" name="nolhp" value="<?php echo $row['nolhp']; ?>"/>
<input type="hidden" name="idpantau" value="<?php echo $row['idpantau']; ?>"/>
<input type="hidden" name="sisapiutang" value="<?php echo $row['sisapiutang']; ?>"/>
<script>
     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(200)
                        .height(200);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
</div>
<br><input style="border-radius:20px;border:0px;padding:10px;width:200px;background:linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;color:#fff" type="submit" onclick="javascript:showDiv()" value="Submit" name="post" />
</form>
			</div></p>
			


  </div>
  

</div>

        </div>
      </div>



    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/datatables.bootstrap4.min.css" rel="stylesheet">
    <!-- Bootstrap core JavaScript-->
    <script src="../assets/jquery.min.js"></script>
    <!-- Page level plugin JavaScript-->=
           
			</div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> Laporan Hasil Pemeriksaan (LHP)
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>