<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<?php 
session_start();
include "../dbconnect.php";	
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
if(!isset($_SESSION['mitra']))
{?>
<script>alert("Login Session Expired, Please login again");</script>
<?php }?>
<style>#loading{position:fixed;left:0;right:0;z-index:99999;background-color:#ffffff7d;height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh}</style>
<?php
include "../dbconnect.php";
if(isset($_POST['send']))
{
$created=date('d-m-Y h:i:s');
$idprod = $_POST['idproduct'];
$mit = $_POST['id_mitra'];
$hrg = $_POST['hrg'];
$qty = $_POST['qty'];
$total = $hrg*$qty;

	$idproduct = trim($idprod);
	// email exist or not
	$query = "SELECT * FROM keranjang WHERE idproduct='$idprod' and status='active' and kodesewa='0'";
	$result = mysqli_query($mysqli, $query);
	$count = mysqli_num_rows($result); // if email not found then register
	
	if($count == 0){
mysqli_query($mysqli,"UPDATE `product` SET `status`='rented', kodesewa='book' WHERE idproduct='$idprod';");
if(mysqli_query($mysqli, "INSERT INTO `keranjang` (`idkeranjang`, `kodesewa`, `created`, `idproduct`, `id_mitra`, `hrg`, `qty`, `total`, `status`) VALUES (NULL, '0', '$created', '$idprod', '$mit', '$hrg', '$qty', '$total', 'active');"))
		{
			?>
<script>document.location.href="index.php";</script>
<?php
		}
		else
		{
			?><div style="color:#F0">Busy Server</div><?php
		}		
	}
	else{
			?>
<script>alert("Already added on rent list");</script>
<script>document.location.href="index.php";</script><?php
	}
	
}
?>
<?php
$r=$_POST['r'];
$query=mysqli_query($mysqli, "select * from product where namaproduct like '%".$r."%' or kodebarang like '%".$r."%' or brand like '%".$r."%' or id_kategori like '%".$r."%' or detail like '%".$r."%' LIMIT 4");
$row=mysqli_num_rows($query);
if ($row > 0) // jika baris lebih dari 0 / data ditemukan
{
	while ($data=mysqli_fetch_array($query)) // perulangna untuk menampilkan data
	{

$bias = $data['hargasewa']; $new = number_format($bias,0,",",".");
		// menampilkan data dalam bentuk table
		echo "<table width='100%' style='font-family:monospace;color:#000;border-bottom:1px solid #d4d4d4;font-size:14px;padding:4px;'>
<thead>
  <tr>
    <th width=46%><b><div style='color:#09c;font-size:13px;text-align:left'>".$data['namaproduct']."</small></div></b><br>".$data['id_kategori']." - ".$data['brand']."</th>
    <th width=25% style='text-align:left;font-size:12px'>".$info['currency']." ".$new.",-/<small>".$set['trans14']."</small></th>";?>

<th width="29%" style=""><?php $sewa=$data['status']; if($sewa=='available'){?><?php echo $set['trans3']?>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="idproduct" value="<?php echo $data['idproduct'];?>"/>
<input type="hidden" name="hrg" value="<?php echo $data['hargasewa'];?>"/>
<input type="hidden" name="id_mitra" value="<?php echo $_SESSION['mitra'];?>"/>
<input style="border-radius:6px;border:1px solid #09c;padding:5px;width:40px" name="qty" type="number" value="1" min="1"  required="required"/>
<input style="padding:3px;border-radius:8px;border:0;width:80px;background:linear-gradient(87deg,#49eca1 0,#5b966d 100%)!important;color:#fff" onclick="javascript:showDiv()" type="submit" value="<?php echo $set['trans4']?>" name="send" /></form>
	<?php } else{?> <center><b style="color:red"><?php echo $set['trans5']?></b></center><?php }?></th>
<?php echo "</tr>
</thead>
</table>";	
	}
}
else // jika data tidak ditemukan
{
	echo "<br><br><center><strong>Not Found</strong></center>";	
}
?>
<div id="loading" style="display:none"><center><br><br><br><img style="margin-top:100px;width:60px" src="../interwind.svg"><br><br></center>
</div>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>