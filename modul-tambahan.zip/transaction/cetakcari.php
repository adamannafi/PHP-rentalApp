<?php
session_start();
include_once '../dbconnect.php';
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
if(!isset($_SESSION['mitra']))
{
?><br>
<center style="color:#444">Nice Try to crack dude!! ;)<br>Your Session is Expired, please Login from Admin App</center>
<?php } else{?>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" />
  <head>
    <style type="text/css">

    #printable { display: none; }

    @media print
    {
        #non-printable { display: none; }
        #printable { display: block; }
    }
    </style>
</head>

<body style="background-color:#fff;padding:15px;font-family:Segoe UI" onload="window.print()">
    <div id="non-printable">
<p style="color:#444;padding:15px">
<center><h4><small>All Rental Data From <?php echo $_POST['from_date'];?> to <?php echo $_POST['to_date'];?></small></h4></center>
<br><br>

 <style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>	
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
  <tr>
    <th class="tg-0lax">No</th>
    <th class="tg-0lax">Rental Detail</th>
    <th class="tg-0lax">Customer Detail</th>
    <th class="tg-0lax">Rent Price</th>
    <th class="tg-0lax">Discount</th>
    <th class="tg-0lax">Discount Price</th>
    <th class="tg-0lax">Status</th>
  </tr>
</thead>
<tbody>
<?php 
$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];
$result = mysqli_query($mysqli, "SELECT * FROM sewa WHERE tanggal BETWEEN '" . $from_date . "' AND  '" . $to_date . "' ORDER by tanggal DESC");
$i = 1;
while($res = mysqli_fetch_array($result)) { 	
$id_mitra=$res['id_mitra'];
$bin=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra='$id_mitra'");
$jas=mysqli_fetch_array($bin);
echo "<tr>";?>
<td width="2%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php
				echo"<td width=50%>INVOICE: ".$res['kodesewa']."<br>Rent Date: ".$res['tanggal']."<br>Return Date: ".$res['tglkembali']."<br>Admin: ".$jas['nama_mitra']."";?>
<table width="100%" style="color:#000;font-family:monospace;font-size:14px;border-style: dotted; border-collapse: collapse;">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">

<th style="color:#000;font-family:monospace"class="description">Item</th>
<th style="color:#000;font-family:monospace"class="quantity"><center>Day Rent</center></th>
<th style="color:#000;font-family:monospace"class="price">Total</th>
</tr>
</thead>
<?php 
$kodesewa=$res['kodesewa'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$kodesewa=$row['kodesewa'];
$query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";
$select = mysqli_query($mysqli,$query);
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as total from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['total']; $mew = number_format($aaaa,0,",",".");
	while ($besult = mysqli_fetch_array($select)) {
$idproduct=$besult['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$sultan=$besult['total'];
$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$sultan*$sidis;
$bingas = $sultan-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td style="color:#000;font-family:monospace;font-size:14px"class="description"><small><?php echo $soq['namaproduct']; ?><br><?php echo $info['currency']; ?><?php echo $soq['hargasewa']; ?>/days</small></td>
<td style="color:#000;font-family:monospace;font-size:14px"class="quantity"><center><?php echo $besult['qty']; ?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $besult['total']; ?></td>
<?php }else{ ?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $bingas; ?></td>
	<?php }?>
</tr>
<?php } ?>
</table><?php if($som == 0){?>

<?php }else{ ?>Discount <?php echo $haka['keterangan_liburan']; ?> <?php echo $haka['diskon']; ?>%</td>

	<?php }?>
		<?php 
		echo"</td>";
		echo"<td >Customer: ".$res['namausers']."<br>ID Nationality: ".$res['ktp']."<br>Address: ".$res['alamat']."<br>Contact: ".$res['contact']."<br>Email: ".$res['email']."<br>Rental Guarantee: ".$res['jaminan']."</td>";
		$jika = $res['harga']; $revenue = number_format($jika,0,",",".");
		echo"<td >".$info['currency']." ".$revenue.",-</td>";
		echo"<td >".$res['diskon']."%</td>";
		$kikas = $res['hargadiskon']; $jenee = number_format($kikas,0,",",".");
		echo"<td >".$info['currency']."  ".$jenee.",-</td>";
		echo"<td >".$res['status']."</td>";
		
		echo "</tr>";	
		
	}
	
	
$kos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(hargadiskon) as total from sewa WHERE tanggal BETWEEN '" . $from_date . "' AND  '" . $to_date . "'"));
$nuas = $kos['total']; $get = number_format($nuas,0,",",".");
	?>
	<tr>
<td style="border:none;" >&nbsp;</td>
<td style="border:none;" >&nbsp;</td>
<td colspan="2" style="border:none;"><b style="float:right">Total</b></td>
<td width="3%" style="border:none;" ><center>:</center></td>
<td  colspan="2" style="border:none;"><center><?php echo $info['currency']; ?> <?php echo $get; ?>,-</center></td>
</tr>
                                    </tbody>
                                </table>
		<br><br>

</p>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
	
<form id="form"action="cetak1export.php"method="post"><center>
<input class="form-control" width="60%"  type="hidden" value="<?php echo $from_date;?>" name="from_date" required="required"><br>
<input class="form-control" width="60%" type="hidden" value="<?php echo $to_date;?>" name="to_date" required="required"><br>
<center><section class="button-demo"><button type="submit"name="tambah" class="btn btn-info btn-lg" style="padding:10px;background: linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;border:none;border-radius:20px;color:#fff;width:80%" > <b>Print Excel</b></button></section>
</center>
</form>
</center>
<center><a href="main.php" class="btn btn-info btn-lg" style="padding:10px;background: red;border:none;border-radius:20px;color:#fff;width:80%">Back</a>
</center>
 <br><br><br>
<div id="loading" style="display:none">
</div>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>
<div id="editor"></div>

    </div>

    <div id="printable">
 <p style="color:#444;padding:15px">
<center><h4><small>All Rental Data From <?php echo $_POST['from_date'];?> to <?php echo $_POST['to_date'];?></small></h4></center>
<br><br>

 <style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>	
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
  <tr>
    <th class="tg-0lax">No</th>
    <th class="tg-0lax">Rental Detail</th>
    <th class="tg-0lax">Customer Detail</th>
    <th class="tg-0lax">Rent Price</th>
    <th class="tg-0lax">Discount</th>
    <th class="tg-0lax">Discount Price</th>
    <th class="tg-0lax">Status</th>
  </tr>
</thead>
<tbody>
<?php 
$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];
$result = mysqli_query($mysqli, "SELECT * FROM sewa WHERE tanggal BETWEEN '" . $from_date . "' AND  '" . $to_date . "' ORDER by tanggal DESC");
$i = 1;
while($res = mysqli_fetch_array($result)) { 	
$id_mitra=$res['id_mitra'];
$bin=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra='$id_mitra'");
$jas=mysqli_fetch_array($bin);
echo "<tr>";?>
<td width="2%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php
				echo"<td width=50%>INVOICE: ".$res['kodesewa']."<br>Rent Date: ".$res['tanggal']."<br>Return Date: ".$res['tglkembali']."<br>Admin: ".$jas['nama_mitra']."";?>
<table width="100%" style="color:#000;font-family:monospace;font-size:14px;border-style: dotted; border-collapse: collapse;">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">

<th style="color:#000;font-family:monospace"class="description">Item</th>
<th style="color:#000;font-family:monospace"class="quantity"><center>Day Rent</center></th>
<th style="color:#000;font-family:monospace"class="price">Total</th>
</tr>
</thead>
<?php 
$kodesewa=$res['kodesewa'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$kodesewa=$row['kodesewa'];
$query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";
$select = mysqli_query($mysqli,$query);
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as total from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['total']; $mew = number_format($aaaa,0,",",".");
	while ($besult = mysqli_fetch_array($select)) {
$idproduct=$besult['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$sultan=$besult['total'];
$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$sultan*$sidis;
$bingas = $sultan-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td style="color:#000;font-family:monospace;font-size:14px"class="description"><small><?php echo $soq['namaproduct']; ?><br><?php echo $info['currency']; ?><?php echo $soq['hargasewa']; ?>/days</small></td>
<td style="color:#000;font-family:monospace;font-size:14px"class="quantity"><center><?php echo $besult['qty']; ?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $besult['total']; ?></td>
<?php }else{ ?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $bingas; ?></td>
	<?php }?>
</tr>
<?php } ?>
</table><?php if($som == 0){?>

<?php }else{ ?>Discount <?php echo $haka['keterangan_liburan']; ?> <?php echo $haka['diskon']; ?>%</td>

	<?php }?>
		<?php 
		echo"</td>";
		echo"<td >Customer: ".$res['namausers']."<br>ID Nationality: ".$res['ktp']."<br>Address: ".$res['alamat']."<br>Contact: ".$res['contact']."<br>Email: ".$res['email']."<br>Rental Guarantee: ".$res['jaminan']."</td>";
		$jika = $res['harga']; $revenue = number_format($jika,0,",",".");
		echo"<td >".$info['currency']." ".$revenue.",-</td>";
		echo"<td >".$res['diskon']."%</td>";
		$kikas = $res['hargadiskon']; $jenee = number_format($kikas,0,",",".");
		echo"<td >".$info['currency']."  ".$jenee.",-</td>";
		echo"<td >".$res['status']."</td>";
		
		echo "</tr>";	
		
	}
	
	
$kos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(hargadiskon) as total from sewa WHERE tanggal BETWEEN '" . $from_date . "' AND  '" . $to_date . "'"));
$nuas = $kos['total']; $get = number_format($nuas,0,",",".");
	?>
	<tr>
<td style="border:none;" >&nbsp;</td>
<td style="border:none;" >&nbsp;</td>
<td colspan="2" style="border:none;"><b style="float:right">Total</b></td>
<td width="3%" style="border:none;" ><center>:</center></td>
<td  colspan="2" style="border:none;"><center><?php echo $info['currency']; ?> <?php echo $get; ?>,-</center></td>
</tr>
                                    </tbody>
                                </table>
		<br><br>
		</p>
		
<center>Copyright @<?php echo $info['namaapp'];?></center>
    </div>
</body>
</body>
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>
<?php }?>