<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
?>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">
<link rel="stylesheet"type="text/css"href="../button.css"/>

</head>
<body style="font-family:monospace;">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background: linear-gradient(87deg, #b9dce4 0, #9fecff 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5" >
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>
  <div class="w3-row" style="width:100%">
    <a style="font-size:16px" href="javascript:void(0)" onclick="openCity(event, 'London');">
      <div style="width:50%;height:50px;border: 1px solid #e0e0e0;border-radius:10px 0 0 0;margin-top:10px;" class="w3-third tablink w3-bottombar w3-hover-light-grey w3-padding"><center>Laporan Hasil Pemeriksaan (LHP)</center></div>
    </a>
    <a style="font-size:16px" href="javascript:void(0)" onclick="openCity(event, 'Paris');">
      <div style="width:50%;height:50px;border: 1px solid #e0e0e0;border-radius:0 10px 0 0;margin-top:10px;" class="w3-third tablink w3-bottombar w3-hover-light-grey w3-padding"><center>Pembayaran</center></div>
    </a>
  </div>

  <div id="London" class="w3-container city" style="display:block"><br>
<center><h4><b>Data Laporan Hasil Pemeriksaan (LHP)
</b></h4>Keseluruhan Data Laporan Temuan</center>
                <div class="col text-right"> 
				<a target="_blank"href="lhp1.php" style="background:#b10a0a;color:#fff" class="btn btn-sm btn-primary">Cetak PDF</a>
                <a target="_blank"href="lhp1export.php" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Cetak Excel</a>
                </div>
<p>

            <div class="table-responsive">
              <!-- Projects table -->
                            <div class="content table-responsive table-full-width">
	<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
                                    <thead><tr>
	<th>No</th>
		<th>NO LHP</th>
		<th>OPD</th>
		<th>TAHUN ANGGARAN</th>
		<th>TAHUN PELAKSANAAN AUDIT</th>
		<th>JUDUL TEMUAN</th>
		<th>REKOMENDASI</th>
		<th>PENANGGUNGJAWAB TEMUAN</th>
		<th>JABATAN SEHUBUNGAN TEMUAN</th>
		<th>NILAI</th>
		<th>INFO MUTASI (PEMBAYARAN/PENGAHPSN) </th>
		<th>TANGGAL LAPORAN</th>
		<th>STATUS (SELESAI/PROSES/BELUM PROSES) </th>
		<th>DATA / DOKUMEN USULAN PENYELESAIAN</th>
		<th>KODE TEMUAN</th>
		<th>PENGHAPUSAN TEMUAN (DEFAULTNYA NORMAL)</th>
<th>x</th>
	
	</tr></thead>
	<?php 
$result = mysqli_query($mysqli, "SELECT * FROM pantau ORDER BY tglpiutang DESC");
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php	
echo "<td>".$res['nolhp']."</td>";
echo "<td>".$res['opd']."</td>";
echo "<td>".$res['thn_anggran']."</td>";
echo "<td>".$res['thn_audit']."</td>";
echo "<td>".$res['judultemuan']."</td>";
echo "<td>".$res['rekom']."</td>";
echo "<td>".$res['penanggungjwb']."</td>";
echo "<td>".$res['jabatan']."</td>";
echo "<td>".$res['nilaipiutang']."</td>";
echo "<td><a href=\"print.php?idpantau=$res[idpantau]\">Lihat mutasi</a></td>";
echo "<td>".$res['tglpiutang']."</td>";
echo "<td>".$res['statusproses']."</td>";
echo "<td>";?>
<a target="_blank"href="../foto_mitra/<?php echo $res['dokumen'];?>"><?php echo $res['dokumen'];?></a>
<?php echo "</td>";
echo "<td>".$res['kodetemuan']."</td>";
echo "<td>".$res['statusdata']."</td>";
echo "<td> <a href=\"delete.php?idpantau=$res[idpantau]\" onClick=\"return confirm('Apakah anda merasa sudah yakin ingin menghapus data ini?')\"><img src=../delete.png width=25px/></a> 
<a href=\"print.php?idpantau=$res[idpantau]\" onClick=\"return confirm('Apakah anda ingin mencetak data ini saja?')\"><img src=../print.png width=25px/></a>			
</td>";				
	}
	?>
	</table>
<?php
	if (isset($_POST['upload'])) {

		require('spreadsheet-reader-master/php-excel-reader/excel_reader2.php');
		require('spreadsheet-reader-master/SpreadsheetReader.php');

		//upload data excel kedalam folder uploads
		$target_dir = "uploads/".basename($_FILES['filemhsw']['name']);
		
		move_uploaded_file($_FILES['filemhsw']['tmp_name'],$target_dir);

		$Reader = new SpreadsheetReader($target_dir);

		foreach ($Reader as $Key => $Row)
		{
			// import data excel mulai baris ke-2 (karena ada header pada baris 1)
			if ($Key < 1) continue;			
			$query=mysqli_query($mysqli,"INSERT IGNORE INTO `pantau` (`idpantau`, `nolhp`, `opd`, `thn_anggran`, `thn_audit`, `judultemuan`, `rekom`, `penanggungjwb`, `jabatan`, `nilaipiutang`, `kodepiutang`, `tglpiutang`, `statusproses`, `dokumen`, `kodetemuan`, `penghapusan`, `id_mitra`, `statusdata`, `id_instansi`, `sisapiutang`) VALUES (NULL, '".$Row[0]."', '".$Row[1]."', '".$Row[2]."', '".$Row[3]."', '".$Row[4]."', '".$Row[5]."', '".$Row[6]."', '".$Row[7]."', '".$Row[8]."', '', '".$Row[9]."', '".$Row[10]."', '".$Row[11]."', '".$Row[12]."', '', '', '".$Row[13]."', '', '".$Row[14]."');");
		}
		if ($query) {
			mysqli_query($mysqli,"DELETE from `pantau` where nilaipiutang=''");	
				echo "Import data berhasil";?>
				<a style="border-radius:20px;border:0px;padding:10px;width:200px;background:linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;color:#fff" href="main.php">Refresh Data</a>
				<?php
			}else{
				echo mysqli_error();
			}
	}
	?>
<table width="100%"><tbody><tr><td>
<b>Import Data</b><br> 
<form method="post" enctype="multipart/form-data" >
Admin dapat menambahkan data Laporan Hasil Pemeriksaan yang Sudah diinput ke aplikasi Excel, format file excel yang digunakan untuk inputan data wajib download dari aplikasi iBase dengan klik tombol download ini<br>
Karena file excel sudah diprogram format .ods agar support dengan program opensource lain seperti OpenOffice, Libre Office dan database server, tidak disarankan menggunakan file excel yang dibuat sendiri karena belum tentu support ketika di import.<br>
<a target="_blank"href="uploads/Lhp.ods" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Download Format Lhp.ods</a>
</td><td><input name="filemhsw" type="file" required="required"><br><br>
<center>
Pilih File format Lhp.ods disini, kemudian klik Import
<br><input style="border-radius:20px;border:0px;padding:10px;width:200px;background:linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;color:#fff" type="submit" onclick="javascript:showDiv()" value="Import" name="upload" />
</form>
</center></td></tr></tbody></table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
			</div></p>
			
          </div>
	  <div id="Paris" class="w3-container city" style="display:none"><br>
	  <center><h4><b>Data Mutasi Pembayaran
</b></h4>Cetak untuk melihat salah Satu Aktivitas Mutasi Pembayaran Temuan</center>
                <div class="col text-right"> 
				<a target="_blank"href="mutasi1.php" style="background:#b10a0a;color:#fff" class="btn btn-sm btn-primary">Cetak PDF</a>
                <a target="_blank"href="mutasi1export.php" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Cetak Excel</a>
                </div>
<p>

            <div class="table-responsive">
              <!-- Projects table -->
	<table class="table table-bordered" style="font-size:12px;" id="daBle" width="100%" cellspacing="0">
                                    <thead><tr>
	<th>No</th>
		<th>Tgl Mutasi</th>
		<th>Atas Nama</th>
		<th>Nilai</th>
		<th>Jenis Mutasi</th>
		<th>Kode Temuan</th>
		<th>Cetak</th>
	
	</tr></thead>
	<?php 
$result = mysqli_query($mysqli, "SELECT * FROM mutasi ORDER BY idmutasi DESC");
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td>
<?php	
echo "<td>".$res['tglmutasi']."</td>";
echo "<td>".$res['atasnama']."</td>";
echo "<td>".$res['nilai']."</td>";
echo "<td>".$res['tipemutasi']."</td>";
echo "<td>".$res['kodetemuan']."</td>";
echo "<td>
<a href=\"printmutasi.php?idmutasi=$res[idmutasi]\" onClick=\"return confirm('Are you sure you want to Print?')\"><img src=../print.png width=25px/></a>		</td>";
}
	?>
	</table><br>
<?php
	if (isset($_POST['mutasi'])) {

		require('spreadsheet-reader-master/php-excel-reader/excel_reader2.php');
		require('spreadsheet-reader-master/SpreadsheetReader.php');

		//upload data excel kedalam folder uploads
		$target_dir = "uploads/".basename($_FILES['filemhsw']['name']);
		
		move_uploaded_file($_FILES['filemhsw']['tmp_name'],$target_dir);

		$Reader = new SpreadsheetReader($target_dir);

		foreach ($Reader as $Key => $Row)
		{
			// import data excel mulai baris ke-2 (karena ada header pada baris 1)
			if ($Key < 1) continue;			
			$query=mysqli_query($mysqli,"INSERT IGNORE INTO `mutasi` (`idmutasi`, `kodemutasi`, `kodetemuan`, `nilai`, `tipemutasi`, `atasnama`, `instansi`, `status`, `tglmutasi`, `id_mitra`, `buktidokumen`) VALUES (NULL, '', '".$Row[0]."', '".$Row[1]."', '".$Row[2]."', '".$Row[3]."', '".$Row[4]."', '".$Row[5]."', '".$Row[6]."', '', '".$Row[7]."');");
		}
		if ($query) {
			mysqli_query($mysqli,"DELETE from `mutasi` where nilai=''");	
				echo "Import data berhasil";?>
				<a style="border-radius:20px;border:0px;padding:10px;width:200px;background:linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;color:#fff" href="main.php">Refresh Data</a>
				<?php
			}else{
				echo mysqli_error();
			}
	}
	?>
<table width="100%"><tbody><tr><td>
<b>Import Data</b><br> 
<form method="post" enctype="multipart/form-data" >
Admin dapat menambahkan data Mutasi yang Sudah diinput ke aplikasi Excel, format file excel yang digunakan untuk inputan data wajib download dari aplikasi iBase dengan klik tombol download ini<br>
Karena file excel sudah diprogram .ods agar support dengan program opensource lain seperti OpenOffice, Libre Office dan database server, tidak disarankan menggunakan file excel yang dibuat sendiri karena belum tentu support ketika di import.<br>
<a target="_blank"href="uploads/mutasi.ods" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Download Format mutasi.ods</a>
</td><td><input name="filemhsw" type="file" required="required"><br><br>
<center>
Pilih File format Mutasi.ods disini, kemudian klik Import
<br><input style="border-radius:20px;border:0px;padding:10px;width:200px;background:linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;color:#fff" type="submit" onclick="javascript:showDiv()" value="Import" name="mutasi" />
</form>
</center></td></tr></tbody></table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#daBle').DataTable();
        });
    </script>
           
			</div></p>
  </div>

  </div>
  

</div>

        </div>
      </div>



	  
<script>
function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-border-red", "London");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.firstElementChild.className += " w3-border-red";
}
</script>

      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> Laporan Hasil Pemeriksaan (LHP)
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>