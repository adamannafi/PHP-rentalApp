<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">
<link rel="stylesheet"type="text/css"href="../button.css"/>

</head>
<body style="font-family:monospace;">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background:linear-gradient(87deg, #ffb7b3 0, #fffbc5 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5" >
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>
<center><h4><b>Data Customer Member
</b></h4><?php echo $set['customer1'];?></center>
<p>
            <div class="table-responsive">
              <!-- Projects table -->
			  	<div class="content table-responsive table-full-width">
 <style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>	
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
  <tr>
    <th class="tg-0lax">No</th>
    <th class="tg-0lax">Picture</th>
    <th class="tg-0lax">Name</th>
    <th class="tg-0lax">Email</th>
    <th class="tg-0lax">ID Nationality</th>
    <th class="tg-0lax">Address</th>
    <th class="tg-0lax">Contact</th>
    <th class="tg-0lax">Navigation</th>
  </tr>
</thead>
<tbody>
<?php 
$result = mysqli_query($mysqli, "SELECT * FROM `customer` ORDER by idcustomer DESC");
$i = 1;
while($res = mysqli_fetch_array($result)) { 
echo "<tr>";?>
<td width="2%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php
				echo"<td width='10%'>";?>
	<?php 
if (empty($res['picture'])) { ?>
<img src="../nopic.png" style="width:100px"/>
<?php }else{ ?>
		<?php
	if($res['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src="../foto_mitra/<?php echo $res['picture'];?>" style="width:100px"/>
<?php }}
		echo"</td>";
				echo"<td ><center>".$res['namacust']."</center><br><br>";?>
<a style="float:right;color:#fff;background:#09c;padding:4px;border-radius:6px" href="laporan.php?ktp=<?php echo $res['ktp'];?>"><?php echo $set['customer2'];?></a><br>		
		<?php echo"</td>";
		echo"<td >".$res['email']."</td>";
		echo"<td >".$res['ktp']."</td>";
		echo"<td >".$res['alamat']."</td>";
		echo"<td >".$res['contact']."</td>";
		echo "<td width=5%>";
		echo"<a style=padding:5px;color:#fff; href=updatecustomer.php?idcustomer=$res[idcustomer]><img src=../edit.png width=25px /></a>"; 
			if($rows['sebagai']=='superuser')
      {
?>
<a href="deletecust.php?idcustomer=<?php echo $res['idcustomer'];?>" onClick="return confirm('Are you sure delete this data?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='pm')
      {
?>
<a href="deletecust.php?idcustomer=<?php echo $res['idcustomer'];?>" onClick="return confirm('Are you sure delete this data?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='am')
      {
?>
<a href="deletecust.php?idcustomer=<?php echo $res['idcustomer'];?>" onClick="return confirm('Are you sure delete this data?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
		echo"</td>";
		echo "</tr>";	
		
	}
	?>
                                    </tbody>
                                </table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">
    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">
    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>
    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
			</div></p>
	    </div>

  </div>
  

</div>

        </div>
      </div>




      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> <?php echo $info['namaapp'];?>
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>