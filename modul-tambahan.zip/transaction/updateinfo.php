<?php
session_start();
include_once '../dbconnect.php';
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from info where idinfo='1'"));
$jesul=mysqli_fetch_array(mysqli_query($mysqli, "select * from settinglang where status='Default'"));
if(isset($_POST['submit']))
{
$namaapp = $_POST['namaapp'];
$address = $_POST['address'];
$city = $_POST['city'];
$country = $_POST['country'];
$phone = $_POST['phone'];
$slogan = $_POST['slogan'];
$thanks = $_POST['thanks'];
$zone = $_POST['zone'];
$email = $_POST['email'];
$currency = $_POST['currency'];

	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['sicture'];
	}else{
		$pipis=$_FILES['picture']['name'];
		$picture=str_replace(" ", "", $pipis);
		//definisikan variabel file dan kendaraan file
		$uploaddir='../fotobarang/';
		$kendaraanfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file(str_replace(" ", "", $_FILES['picture']['tmp_name']),$kendaraanfile);
	}
	
	if(empty($_FILES['logo']['name'])){
		$logo=$_POST['bogo'];
	}else{
		$jais=$_FILES['logo']['name'];
		$logo=str_replace(" ", "", $jais);
		$logo=$_FILES['logo']['name'];
		//definisikan variabel file dan kendaraan file
		$jumpakj='../foto_mitra/';
		$limes=$jumpakj.$logo;
		//periksa jika proses upload berjalan sukses
		$rupso=move_uploaded_file($_FILES['logo']['tmp_name'],$limes);
	}
	
	$idsetlang=$_POST['idsetlang'];
	$idawal=$_POST['idawal'];
mysqli_query($mysqli, "update settinglang set status='' where idsetlang='$idawal'");
mysqli_query($mysqli, "update settinglang set status='Default' where idsetlang='$idsetlang'");			
$query=mysqli_query($mysqli, "UPDATE `info` SET `currency` = '$currency', `email` = '$email', `namaapp` = '$namaapp', `picture` = '$picture', `address` = '$address', `city` = '$city', `country` = '$country', `poscode` = '$poscode', `phone` = '$phone', `slogan` = '$slogan', `thanks` = '$thanks', `logo` = '$logo', `zone` = '$zone' WHERE `info`.`idinfo` = '1';");
if($query){
	header("Location: updateinfo.php");
	}else{
		echo mysql_query();
	}

}else{
	unset($_POST['submit']);
}
?>
	<meta charset="utf-8" />
	<html>
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body style="padding:25px;"><center>
<div class="wrapper">
 
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" >
                        <div class="card">
                            <div class="header">
						     <h4 class="title">Update Settings information</h4>
                              </div><br><br>
                            <div class="content table-responsive table-full-width">
                                <form id="form"action="updateinfo.php" enctype="multipart/form-data"  method="post" name="postform" style="padding:10px">
<table width=100%>
<tr>
<td width=15% style=padding:10px>Image Store Branding</td>
<td width=2% style=padding:10px>:</td>
<td width=83% style=padding:10px>
<table width="100%">
<tr>
<td width="50%"><?php 
if (empty($row['picture'])) { ?>
<img src="../nopic.png" style="width:100px"/>
<?php }else{ ?>
		<?php
	if($row['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src="../fotobarang/<?php echo $row['picture'];?>" style="width:250px"/>
<?php }}?></td>
<td width="50%"> <?php 
if (empty($row['logo'])) { ?>
<img src="../nopic.png" style="width:100px"/>
<?php }else{ ?>
		<?php
	if($row['logo']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src="../fotobarang/<?php echo $row['logo'];?>" style="width:100px"/>
<?php }}?></td>
</tr>
<tr>
<td><small>Change Image Branding Logo</small><br>
<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="file" name="picture" size="999999" >
<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" value="<?php echo $row['picture'];?>" type="hidden" name="sicture" size="999999" required >
</td>
<td><small>Change Icon</small><br>
<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="file" name="logo" size="999999" >
<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" value="<?php echo $row['logo'];?>" type="hidden" name="bogo" size="999999" required >
</td>
</tr>
</table>
</td>
</tr><tr>
<tr>
<td style=padding:10px>Store Name</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['namaapp'];?>" name="namaapp"required=required></td>
</tr><tr>
<td style=padding:10px>Adress</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['address'];?>" name="address"required=required></td>
</tr>

<tr>
<td style=padding:10px>City</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['city'];?>" name="city"required=required></td>
</tr>
<tr>
<td style=padding:10px>Country</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['country'];?>" name="country"required=required></td>
</tr>
<tr>
<td style=padding:10px>Phone</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=number value="<?php echo $row['phone'];?>" name="phone"required=required></td>
</tr>
<tr>
<td style=padding:10px>Email</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['email'];?>" name="email"required=required></td>
</tr>
<tr>
<td style=padding:10px>Store Message</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['slogan'];?>" name="slogan"></td>
</tr>
<tr>
<td style=padding:10px>Thanks Message</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['thanks'];?>" name="thanks"></td>
</tr>
<tr>
<td style=padding:10px>Default Time Zone</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['zone'];?>" name="zone"required=required></td>
</tr>
<tr>
<td style=padding:10px>Default Currency</td>
<td style=padding:10px>:</td>
<td style=padding:10px><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type=text value="<?php echo $row['currency'];?>" name="currency"required=required></td>
</tr>
<tr>
<td style=padding:10px>Default Language</td>
<td style=padding:10px>:</td>
<td style=padding:10px>
<input type="hidden" name="idawal" value="<?php echo $jesul['idsetlang'];?>">
<b>Default Language now is <?php echo $jesul['nameset'];?></b><br>
 <select style="padding:10px;background:#dadada" name="idsetlang" > 
    <?php
session_start();
include_once '../dbconnect.php';
		$get=mysqli_query($mysqli, "SELECT * FROM settinglang");
            while($jim = mysqli_fetch_assoc($get))
            {
            ?>
            <option name="idsetlang" style="color:grey"value="<?php echo $jim['idsetlang'];?>" >
                <b style="color:grey"><?php echo $jim['nameset']; ?>-<?php echo $jim['status']; ?></b>
            </option>
            <?php
            }               
        ?>
         </select>
		 </td>
</tr>
</table>
<input type="hidden" name="idcustomer" value="<?php echo $_GET['idcustomer'];?>" />
<center>
<button type="submit" name="submit" class="btn btn-info btn-lg" style="background-color:#09c;color:#fff;z-index:9999;width:80%;height:70px" data-color="blue">SAVE<br></button><br>
</center>
<br><br><br>
	</form>
                            </div>
                        </div>
                    </div>


                 

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <?php echo $info['namaapp'];?>
                </p>
            </div>
        </footer>


</div>
</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo puUSD se -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</center>

</html>
