<?php
include_once '../dbconnect.php';
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
if (!$mysqli) {
    die('Could not connect: ' . mysqli_error($mysqli));
} 
session_start();
if(!isset($_SESSION['mitra']))
{?>
<script>alert("Login Session Expired, Please login again");</script>
<?php }
?>
<body style="color:#000;font-family:monospace;font-size:12px">
<table width="100%" style="color:#000;font-family:monospace;font-size:14px">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<th width="50%" style="padding:3px"><?php echo $set['trans9']?></th>
<th width="5%" style="padding-top:3px"><center><?php echo $set['trans10']?></center></th>
<th width="20%" style="padding-top:3px"><center><?php echo $set['trans13']?></center></th>
<th width="25%" style="padding:3px"><?php echo $set['trans11']?></th>
</tr>
<?php 
$query = "SELECT * FROM keranjang where status='active' and kodesewa='0'";
$select = mysqli_query($mysqli,$query);
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as total from keranjang where status='active' and kodesewa='0'"));
$aaaa = $nos['total']; $mew = number_format($aaaa,0,",",".");
while ($result = mysqli_fetch_array($select)) {
$idproduct=$result['idproduct'];    
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));
       
   ?>
<tr>
<td width="40%" style="color:#000;font-family:monospace;font-size:15px"><small><?php echo $row['namaproduct']; ?></small></td>
<td width="5%" style="color:#000;font-family:monospace;font-size:15px"><center><?php echo $result['qty']; ?></center></td>
<td width="20%" style="color:#000;font-family:monospace;font-size:15px"><center><?php echo $result['hrg']; ?></center></td>
<td width="35%"style="color:#000;font-family:monospace;font-size:15px;"><?php echo $result['total']; ?></td>
</tr>
<?php } ?>
</thead>
</table>
<table width="100%" style="color:#000;font-family:monospace;font-size:15px">
<tr width="100%" style="border-right:0;border-left:0;border-top:1px solid #000;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<td width="35%" style="padding:3px">&nbsp;</td>
<td width="5%" style="padding-top:3px">&nbsp;</td>
<td width="20%" style="padding-top:3px"><?php echo $set['trans11']?> :</td>
<td width="40%" style="padding:3px"><?php echo $info['currency']?> <?php echo $mew; ?>,- </td>
</tr>
</table>
</body>
<?php
$zone=$info['zone'];
date_default_timezone_set(''.$zone.'');
$startTime = date("d-M-Y");
$startHour = date("H:i:s");
$pike = date("Y-m-d H:i:s");
$timestamp = strtotime($pike);
$timestamp_one_hour_later = $timestamp + 3600; // 3600 sec. = 1 hour

$cenvertedTime = date('Y-m-d H:i:s',strftime($timestamp_one_hour_later));
?>
<center> 
<h1><small>Time now:</small><br><?php echo $startHour;?></h1><small><?php echo $startTime;?></small></center>