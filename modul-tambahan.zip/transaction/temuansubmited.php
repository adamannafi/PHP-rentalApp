<?php 
session_start();
include_once("dbconnect.php");

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
?>
<meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible"content="IE=edge,chrome=1">
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"href="demo.css">
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">
<link rel="stylesheet"type="text/css"href="../button.css"/>

</head>
<body style="font-family:monospace;">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background: linear-gradient(87deg, #b9dce4 0, #9fecff 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5" >
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>

						<a href="index.php" onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Back</i></a><br>
<center><h4><b>Data Laporan Hasil Pemeriksaan (LHP)
</b></h4>Keseluruhan Data Laporan Temuan</center>
                <div class="col text-right"> 
				<a href="trafo1.php" style="background:#b10a0a;color:#fff" class="btn btn-sm btn-primary">Cetak PDF</a>
                <a href="trafo1export.php" style="background:#247b24;color:#fff" class="btn btn-sm btn-primary">Cetak Excel</a>
                </div>
<p>

            <div class="table-responsive">
              <!-- Projects table -->
                            <div class="content table-responsive table-full-width">
	<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
                                    <thead><tr>
	<th>No</th>
		<th>NO LHP</th>
		<th>OPD</th>
		<th>TAHUN ANGGARAN</th>
		<th>TAHUN PELAKSANAAN AUDIT</th>
		<th>JUDUL TEMUAN</th>
		<th>REKOMENDASI</th>
		<th>PENANGGUNGJAWAB TEMUAN</th>
		<th>JABATAN SEHUBUNGAN TEMUAN</th>
		<th>NILAI</th>
		<th>INFO MUTASI (PEMBAYARAN/PENGAHPSN) </th>
		<th>TANGGAL MUTASI</th>
		<th>STATUS (SELESAI/PROSES/BELUM PROSES) </th>
		<th>DATA / DOKUMEN USULAN PENYELESAIAN</th>
		<th>KODE TEMUAN</th>
		<th>PENGHAPUSAN TEMUAN (DEFAULTNYA NORMAL)</th>
<th>x</th>
	
	</tr></thead>
	<?php 
$result = mysqli_query($mysqli, "SELECT * FROM pantau ORDER BY tglpiutang DESC");
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php	
echo "<td>".$res['nolhp']."</td>";
echo "<td>".$res['opd']."</td>";
echo "<td>".$res['thn_anggran']."</td>";
echo "<td>".$res['thn_audit']."</td>";
echo "<td>".$res['judultemuan']."</td>";
echo "<td>".$res['rekom']."</td>";
echo "<td>".$res['penanggungjwb']."</td>";
echo "<td>".$res['jabatan']."</td>";
echo "<td>".$res['nilaipiutang']."</td>";
echo "<td>info mutasi</td>";
echo "<td>".$res['tglpiutang']."</td>";
echo "<td>".$res['statusproses']."</td>";
echo "<td>".$res['dokumen']."</td>";
echo "<td>".$res['kodetemuan']."</td>";
echo "<td>".$res['penghapusan']."</td>";
echo "<td> <a href=\"delete.php?idperalatan=$res[kodetemuan]\" onClick=\"return confirm('Are you sure you want to delete?')\"><img src=../delete.png width=25px/></a> 
<a href=\"print.php?idmutasi=$res[idmutasi]\" onClick=\"return confirm('Are you sure you want to Print?')\"><img src=../print.png width=25px/></a>			
</td>";				
	}
	?>
	</table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
			</div></p>
			

  </div>

  </div>
  

</div>

        </div>
      </div>





      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> Laporan Hasil Pemeriksaan (LHP)
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>
<?php
if(isset($_POST['kirim'])){
date_default_timezone_set("Asia/Jakarta");
$tglpiutang = date('Y-m-d');

$nolhp=$_POST['nolhp'];
$opd=$_POST['opd'];
$thn_anggran=$_POST['thn_anggran'];
$thn_audit=$_POST['thn_audit'];
$judultemuan=$_POST['judultemuan'];
$rekom=$_POST['rekom'];
$penanggungjwb=$_POST['penanggungjwb'];
$jabatan=$_POST['jabatan'];
$nilaipiutang=$_POST['nilaipiutang'];
$kodepiutang=$_POST['kodepiutang'];
$statusproses=$_POST['statusproses'];
$kodetemuan=$_POST['kodetemuan'];
$id_mitra=$_POST['id_mitra'];
$statusdata='NORMAL';
$id_instansi=$_POST['id_instansi'];
$sisapiutang=$_POST['nilaipiutang'];

$input = "SELECT * FROM pantau WHERE nolhp='$nolhp' and YEAR(tglpiutang) = YEAR(NOW( )) AND MONTH(tglpiutang) = MONTH(NOW( )) AND DATE(tglpiutang) = DATE(NOW( ))";
$result = mysqli_query($mysqli,$input);
$count = mysqli_num_rows($result); 
$sanas = mysqli_fetch_array($result);
if($count == 0){
$dokumen = $_POST['dokumen'];
	if(empty($_FILES['dokumen']['name'])){
		$dokumen=$_POST['dokumen'];
	}else{
		$dokumen=$_FILES['dokumen']['name'];
		//definisikan variabel file dan kendaraan file
		$jumpakj='../foto_mitra/';
		$limes=$jumpakj.$dokumen;
		//periksa jika proses upload berjalan sukses
		$rupso=move_uploaded_file($_FILES['dokumen']['tmp_name'],$limes);
	}
	if(mysqli_query($mysqli,"INSERT INTO `pantau` (`idpantau`, `nolhp`, `opd`, `thn_anggran`, `thn_audit`, `judultemuan`, `rekom`, `penanggungjwb`, `jabatan`, `nilaipiutang`, `kodepiutang`, `tglpiutang`, `statusproses`, `dokumen`, `kodetemuan`, `penghapusan`, `id_mitra`, `statusdata`, `id_instansi`, `sisapiutang`) VALUES (NULL, '$nolhp', '$opd', '$thn_anggran', '$thn_audit', '$judultemuan', '$rekom', '$penanggungjwb', '$jabatan', '$nilaipiutang', '$kodepiutang', '$tglpiutang', '$statusproses', '$dokumen', '$kodetemuan', '$penghapusan', '$id_mitra', '$statusdata', '$id_instansi', '$sisapiutang');"))
		
		{
mysqli_query($mysqli,"INSERT INTO `abr_opd` (`id_opd`, `kode`, `nama_opd`, `alamat`, `telepon`, `eselon`, `tgl_revisi`, `user_revisi`) VALUES (NULL, NULL, '$opd', NULL, NULL, NULL, '$tglpiutang', NULL);");	
mysqli_query($mysqli,"INSERT INTO `users` (`id`, `oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `picture`, `link`, `created`, `modified`, `email`, `password`, `forgot_pass_identity`, `saldo`, `pembelian`, `noktp`, `tempatlahir`, `tgllahir`, `kelamin`, `agama`, `alamat1`, `kota`, `kecamatan`, `phone`, `kunci`, `sebagai`, `online`, `lat`, `lng`, `kelurahan`, `passport`, `expired`, `office`, `nama_ayah`, `referal_mitra`) VALUES (NULL, '', '', '$penanggungjwb', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', 'user', '', '', '', '', '', '', '', '', '');");	
			?>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Laporan sudah tersimpan</h4>
            </div>
            <div class="modal-body"><center>
			<div align="center"><br>
<img src="success.gif"style="width:100%;height:auto;"></div>
			<p style="color:#444;font-weight:bold">Silahkan cek data yang sudah masuk</p>
<br>
<a href="temuansubmited.php"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto"class="ladda-button"data-color="green"data-style="expand-right">Lihat Data</button>
</section>
</a>
</center>
            </div>
        </div>
    </div>
</div>
			<?php
		}
		else
		{
		}		
	}else{
					?>
<style type="text/css">ul{padding:0;list-style:none}ul li{display:inline-block;position:relative;line-height:21px;text-align:left}ul li a{display:block;padding:8px 25px;color:;text-decoration:none}ul li a:hover{color:#red}ul li ul.dropdown{min-width:100%;background-color:#FFF;display:none;position:absolute;z-index:999;left:-50px;top:35px;border:1px solid grey}ul li:hover ul.dropdown{display:block}ul li ul.dropdown li{display:block}#home{display:none}#loading{display:block;position:absolute;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Laporan Sudah Ada dalam Database</h4>
            </div>
            <div class="modal-body"><center>
			<div align="center"><br>
<img src="success.gif"style="width:100%;height:auto;"></div>
			<p style="color:#444;font-weight:bold">Silahkan cek data yang masuk, Jika ingin menambahkan laporan baru klik tombol Kembali</p>
<br>
<a href="index.php"><section class="button-demo" style="padding:0px">
<button style="border-radius:10px;width:90%;font-size:12px;height:auto"class="ladda-button"data-color="green"data-style="expand-right">Kembali</button>
</section>
</a>
</center>


            </div>
        </div>
    </div>
</div>
			<?php
	}


}	

?>	

<div id="loading" style="display:none">
</div>
</body>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"};</script>
<script src="dist/spin.min.js"></script>
<script src="dist/ladda.min.js"></script>
<script>Ladda.bind(".button-demo button");Ladda.bind(".progress-demo button",{callback:function(e){var f=0;var d=setInterval(function(){f=Math.min(f+Math.random()*0.1,1);e.setProgress(f);if(f===1){e.stop();clearInterval(d)}},200)}});</script>
