<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
//deleting the row from table

mysqli_query($mysqli,"UPDATE `product` SET `status`='available', `kodesewa`='0' WHERE kodesewa='book';");
$result = mysqli_query($mysqli, "DELETE FROM `keranjang` where status='active' and kodesewa='0'");
//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>