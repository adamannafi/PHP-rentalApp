<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$kodesewa = $_GET['kodesewa'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$kodesewa=$row['kodesewa'];
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
    </head><body style="color:#000;font-family:monospace;font-size:12px">
        <div class="ticket">
           <center>
<img src=../logostreet.png style=margin:0;width:100%;height:auto alt="..."/><br><small style=font-size:11px;color:#444>
<?php echo $info['namaapp']?> -
<?php echo $info['address']?> <br><?php echo $info['city']?>, <?php echo $info['country']?>. - Phone <?php echo $info['phone']?>
</center></small><br>
INVOICE #<?php echo $kodesewa;?><br>
<?php echo $set['sewa13']?>: <?php echo $row['namausers'];?> <br>
<?php echo $set['sewa11']?>: <?php echo $row['tglsewa'];?> / <?php 
	$tanggal=$row['tanggal'];
	$timestamp = strtotime($tanggal);
	$hon=date("h.i.s a", $timestamp);
	echo $hon;?><br>
<?php echo $set['sewa12']?>: <?php echo $row['tglkembali'];?><br><br><br>
<table width="100%" style="color:#000;font-family:monospace;font-size:14px">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">

<th style="color:#000;font-family:monospace"class="description"><?php echo $set['item1']?></th>
<th style="color:#000;font-family:monospace"class="quantity"><center><?php echo $set['trans10']?></center></th>
<th style="color:#000;font-family:monospace"class="price"><?php echo $set['trans11']?></th>
</tr>
</thead>
<?php 

  $query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";

$select = mysqli_query($mysqli,$query);
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as total from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['total']; $mew = number_format($aaaa,0,",",".");
	while ($result = mysqli_fetch_array($select)) {
$idproduct=$result['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$sultan=$result['total'];
$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$sultan*$sidis;
$bingas = $sultan-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td style="color:#000;font-family:monospace;font-size:14px"class="description"><small><?php echo $soq['namaproduct']; ?></small></td>
<td style="color:#000;font-family:monospace;font-size:14px"class="quantity"><center><?php echo $result['qty']; ?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $result['total']; ?></td>
<?php }else{ ?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $bingas; ?></td>
	<?php }?>
</tr>
<?php } ?>
</table>
<table width="100%"><?php if($som == 0){?>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<td style="color:#000;font-family:monospace"class="description"><?php echo $set['trans11']?></td>
<td style="color:#000;font-family:monospace"class="quantity" >:</td>
<td style="color:#000;font-family:monospace"class="description"><?php echo $info['currency']?><?php echo $mew; ?>,- </td>
</tr>
<?php }else{ ?>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<td colspan='2' style="color:#000;font-family:monospace"class="description">Discount <?php echo $haka['keterangan_liburan']; ?></td>
<td style="color:#000;font-family:monospace"class="description"><?php echo $haka['diskon']; ?>%</td>
</tr>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<td style="color:#000;font-family:monospace"class="description"><?php echo $set['trans11']?></td>
<td style="color:#000;font-family:monospace"class="quantity" >:</td>
<td style="color:#000;font-family:monospace"class="description"><?php echo $info['currency']?><?php echo $kem; ?>,- </td>
</tr>
	<?php }?>
</table><br><br>
<center><?php echo $set['trans25']?>: <?php echo $sel['jaminan']?><br><br><?php echo $set['trans27']?>: <?php echo $sel['keterangan']?></center>

            <p class="centered"><?php echo $info['slogan']?><small><?php echo $info['thanks']?></small></p>
        </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script src="script.js"></script>
    </body>
</html>