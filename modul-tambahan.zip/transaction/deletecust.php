<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}

//getting id of the data from url
$idcustomer = $_GET['idcustomer'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM customer WHERE idcustomer='$idcustomer'");

//redirecting to the display page (index.php in our case)
header("Location:customer.php");
?>