<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$kodesewa = $_GET['kodesewa'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$kodesewa=$row['kodesewa'];
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<meta charset="utf-8" />
	<html>
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body style="font-family:monospace" onload="window.print()"><center>
<div class="wrapper">
 
        <div class="content" style="margin-top:-70px">
            <div class="container-fluid">
			<br><br><br><br><br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
<table width="100%">
<thead>
  <tr>
    <th width="55%" style="padding:20px"><center>
<img src=../logostreet.png style=margin:0;width:200px;height:auto alt="..."/><br><small style=font-size:10px;color:#444><?php echo $info['namaapp']?> -
<?php echo $info['address']?> <br><?php echo $info['city']?>, <?php echo $info['country']?>. - Phone <?php echo $info['phone']?>
</center></small></th>
    <th width="25%"></th>
    <th width="20%" style="padding:20px"><center><b style="font-size:29px">INVOICE</b><br><b style="font-size:15px">#<?php echo $kodesewa;?></b></center></th>
  </tr>
</thead>
<tbody>
  <tr>
    <td style="padding:20px"><?php echo $set['sewa14']?>:<br><?php echo $row['namausers'];?><br><?php echo $row['alamat'];?><br><?php echo $row['contact'];?><br><?php echo $row['email'];?></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>
	<table width="100%">
<thead>
  <tr>
    <th style="padding:20px" ><?php echo $set['sewa13']?><br><small><?php echo $row['tanggal'];?></small></th>
    <th style="padding:20px"><?php echo $set['sewa11']?><br><small><?php echo $row['tglkembali'];?></small></th>
    <th style="padding:20px">Admin<br><small><?php echo $rows['nama_mitra'];?></small></th>
  </tr>
</thead>

</table>
	</td>
    <td></td>
    <td></td>
  </tr>
</tbody>
</table>
<style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
</style>
<table class=tg width=100%>
<thead>
  <tr>
    <th class="tg-amwm"><?php echo $set['item7']?></th>
    <th class="tg-amwm"><?php echo $set['item8']?></th>
    <th class="tg-amwm"><?php echo $set['trans10']?></th>
    <th class="tg-amwm"><?php echo $set['trans11']?></th>
  </tr>
</thead>
<?php 
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as kor from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['kor']; $mew = number_format($aaaa,0,",",".");
$query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";
$select = mysqli_query($mysqli,$query);
while ($result = mysqli_fetch_array($select)) {
$idproduct=$result['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$das = $soq['hargasewa']; $fre = number_format($das,0,",",".");
$bias = $result['total']; $new = number_format($bias,0,",",".");


$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$bias*$sidis;
$bingas = $bias-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td>
<?php if (empty($soq['picture'])) { ?>
<img src=../nopic.png style="width:100px"/>
<?php }else{ 
	if($soq['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src=../fotobarang/<?php echo $soq['picture'];?> style="width:100px"/>
<?php }}?></td>
<td ><?php echo $soq['namaproduct']; ?><br><small><?php echo $set['item11']?>: <?php echo $info['currency']?> <?php echo $fre; ?>/<?php echo $set['trans10']?></small></td>
<td><center><?php echo $result['qty']; ?> <?php echo $set['trans10']?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td><center><?php echo $info['currency']?> <?php echo $new; ?></center></td>
<?php }else{ ?>
<td><center><?php echo $info['currency']?> <?php echo $jen; ?></center></td>
	<?php }?>
</tr>
<?php } ?>
<tr>
<?php if($som == 0){?>
<td style="border:none;" >&nbsp;</td>
	<?php }else{ ?>
<td style="border:none;" >Discount <?php echo $haka['keterangan_liburan']; ?> <?php echo $haka['diskon']; ?>%</td>	
	<?php }?>
<td style="border:none;"><b style="float:right">TOTAL</b></td>

<td width="3%" style="border:none;" ><center>:</center></td>
<?php if($som == 0){?>
<td style="border:none;"><center><?php echo $info['currency']?> <?php echo $mew; ?>,-</center></td>
	<?php }else{ ?>
<td style="border:none;"><center><?php echo $info['currency']?> <?php echo $kem; ?>,-</center></td>
	<?php }?>
</tr>
</tbody>
</table>
<br><br>
<center><?php echo $set['trans25']?>: <?php echo $sel['jaminan']?><br><br><?php echo $set['trans27']?>: <?php echo $sel['keterangan']?></center><br>
<table width="100%" style="color:#000;font-weight:bold;font-size:15">
<tr width="100%" style="border-right:0;border-left:0;border-top:1px solid #000;border-bottom:1px solid #000;border-style:dashed;padding:3px;font-weight:normal">
<td width="50%" style="padding:3px"><?php echo $info['slogan']?><br><?php echo $info['thanks']?></td>
<td width="25%" style="padding:3px">&nbsp;</td>
<td width="5%" style="padding-top:3px">&nbsp;</td>
<td width="20%" style="padding-top:3px">&nbsp;</td>
</tr>
</table>


                            </div>
                        </div>
                    </div>


                 

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <?php echo $info['namaapp']?>
                </p>
            </div>
        </footer>


</div>
</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo puUSD se -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</center>

</html>
