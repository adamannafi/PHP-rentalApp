<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../dashboard.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);

$ktp = $_GET['ktp'];
$kom=mysqli_fetch_array(mysqli_query($mysqli, "select * from customer where ktp='$ktp'"));
?>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.1" rel="stylesheet" /><link rel="stylesheet" href="../w3.css">
<link rel="stylesheet"type="text/css"href="../button.css"/>

</head>
<body style="font-family:monospace;">
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8" style="background:linear-gradient(87deg, #ffb7b3 0, #fffbc5 100%) !important;">
    </div>
    <div class="container-fluid mt--7">

      <div class="row mt-5" >
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
<div class="w3-container"><br>
<a href="customer.php" onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Back</i></a><br>
<center>
<center><h4><small>Rental Tracking Member <?php echo $kom['namacust'];?></small></h4></center>
</h4>For print this data<br>Click button Print PDF </center>
                <div class="col text-right">
				<a target="_blank"href="cetak.php?ktp=<?php echo $_GET['ktp'];?>" style="background:#b10a0a;color:#fff" class="btn btn-sm btn-primary">Print PDF</a>
                </div><br>

<p>

            <div class="table-responsive">
              <!-- Projects table -->
			  	
                            <div class="content table-responsive table-full-width">

 <style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>	
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
  <tr>
    <th class="tg-0lax">No</th>
    <th class="tg-0lax">Rent Details</th>
    <th class="tg-0lax">Detail Customer</th>
    <th class="tg-0lax">Rent Prices</th>
    <th class="tg-0lax">Discount</th>
    <th class="tg-0lax">Discount Prices</th>
    <th class="tg-0lax">Status</th>
    <th class="tg-0lax">Navigation</th>
  </tr>
</thead>
<tbody>
<?php 
$ktp = $_GET['ktp'];
$result = mysqli_query($mysqli, "SELECT * FROM `sewa` where ktp='$ktp'");
$i = 1;
while($res = mysqli_fetch_array($result)) { 	
$id_mitra=$res['id_mitra'];
$bin=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra='$id_mitra'");
$jas=mysqli_fetch_array($bin);
echo "<tr>";?>
<td width="2%"style="">
<?php
echo $i;
$i++;
?>
</td>
	<?php
		echo"<td >INVOICE: ".$res['kodesewa']."<br>Rent Date: ".$res['tanggal']."<br>Return: ".$res['tglkembali']."<br>Admin: ".$jas['nama_mitra']."";?>
		<table width="100%" style="color:#000;font-family:monospace;font-size:14px;border-style: dotted; border-collapse: collapse;">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">

<th style="color:#000;font-family:monospace"class="description">Item Name</th>
<th style="color:#000;font-family:monospace"class="quantity"><center>Rent Day</center></th>
<th style="color:#000;font-family:monospace"class="price">Total</th>
</tr>
</thead>
<?php 
$kodesewa=$res['kodesewa'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$kodesewa=$row['kodesewa'];
$query = "SELECT * FROM keranjang where kodesewa='$kodesewa'";
$select = mysqli_query($mysqli,$query);
$nos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(total) as total from keranjang where kodesewa='$kodesewa'"));
$aaaa = $nos['total']; $mew = number_format($aaaa,0,",",".");
	while ($besult = mysqli_fetch_array($select)) {
$idproduct=$besult['idproduct'];    
$soq=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

$sultan=$besult['total'];
$sel=mysqli_fetch_array(mysqli_query($mysqli, "select * from sewa where kodesewa='$kodesewa'"));
$hargadiskon=$sel['hargadiskon']; $kem = number_format($hargadiskon,0,",",".");
$diskon=$sel['diskon'];
$sidis=$diskon/100;
$bundle=$sultan*$sidis;
$bingas = $sultan-$bundle; $jen = number_format($bingas,0,",",".");
   ?>
<tr>
<td style="color:#000;font-family:monospace;font-size:14px"class="description"><small><?php echo $soq['namaproduct']; ?><br><?php echo $info['currency']; ?> <?php echo $soq['hargasewa']; ?>/days</small></td>
<td style="color:#000;font-family:monospace;font-size:14px"class="quantity"><center><?php echo $besult['qty']; ?></center></td>
<?php 
$som=$row['id_diskon'];
$haka=mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM liburnasional WHERE id_liburan='$som'"));
	if($som == 0){
?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $besult['total']; ?></td>
<?php }else{ ?>
<td style="color:#000;font-family:monospace;font-size:14px"class="price"><?php echo $bingas; ?></td>
	<?php }?>
</tr>
<?php } ?>
</table><?php if($som == 0){?>

<?php }else{ ?>Discount <?php echo $haka['keterangan_liburan']; ?> <?php echo $haka['diskon']; ?>%</td>

	<?php }?>
		<?php 
		echo"</td>";
		echo"<td >Customer Name: ".$res['namausers']."<br>ID Nationality: ".$res['ktp']."<br>Address: ".$res['alamat']."<br>Contact: ".$res['contact']."<br>Email: ".$res['email']."<br>Rent Guarantee: ".$res['jaminan']."</td>";
		$jika = $res['harga']; $revenue = number_format($jika,0,",",".");
		echo"<td >Rp.".$revenue.",-</td>";
		echo"<td >".$res['diskon']."%</td>";
		$kikas = $res['hargadiskon']; $jenee = number_format($kikas,0,",",".");
		echo"<td >Rp.".$jenee.",-</td>";
		echo"<td >".$res['status']."</td>";
echo "<td>";
	if($rows['sebagai']=='superuser')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete this?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='pm')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
	  	if($rows['sebagai']=='am')
      {
?>
<a href="delete.php?kodesewa=<?php echo $res['kodesewa'];?>" onClick="return confirm('Are you sure delete?')"><img src="../delete.png" width="25px"></a> 
	  <?php }
echo "<a href=\"printstruk.php?kodesewa=$res[kodesewa]\" target=_blank onClick=\"return confirm('Wanna print to thermal paper?')\"><img src=../print.png width=25px/></a>";			
echo "<a style=padding:5px href=\"print.php?kodesewa=$res[kodesewa]\" target=_blank onClick=\"return confirm('Print to paper A4?')\"><img src=../print.png width=25px/><b style=color:#09c;margin-left:-10px>A4</b></a>";			

echo "</td>";	
		
		echo "</tr>";	
		
	}
$kos=mysqli_fetch_array(mysqli_query($mysqli, "select sum(hargadiskon) as total from sewa where ktp='$ktp'"));
$nuas = $kos['total']; $get = number_format($nuas,0,",",".");
	?>
	<tr>
<td style="border:none;" >&nbsp;</td>
<td style="border:none;" >&nbsp;</td>
<td colspan="2" style="border:none;"><b style="float:right">Total</b></td>
<td width="3%" style="border:none;" ><center>:</center></td>
<td  colspan="2" style="border:none;"><center><?php echo $info['currency'];?> <?php echo $get; ?>,-</center></td>
</tr>
                                    </tbody>
                                </table>
                            </div>
     <link href="../assets-bootsrap/bootstrap.min.css" rel="stylesheet">

    <link href="../assets-bootsrap/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets-bootsrap/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets-bootsrap/jquery.datatables.min.js"></script>

    <script src="../assets-bootsrap/datatables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
			</div></p>
	    </div>

  </div>
  

</div>

        </div>
      </div>



	  
<script>
function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-border-red", "London");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.firstElementChild.className += " w3-border-red";
}
</script>

      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
                     <div class="copyright text-center text-xl-left text-muted">
              &copy; <?php echo date('Y');?> <?php echo $info['namaapp'];?>
            </div>
          </div>
        </div>
      </footer>
    </div>

</body>

</html>