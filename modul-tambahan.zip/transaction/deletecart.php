<?php
include '../dbconnect.php'; 
// sorry need to get id 
$id = $_POST['delete_id'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from keranjang where idkeranjang='$id'"));
$idprod=$row['idproduct'];
mysqli_query($mysqli,"UPDATE `product` SET `status`='available', `kodesewa`='0' WHERE idproduct='$idprod';");
$query = mysqli_query($mysqli,"DELETE FROM keranjang WHERE idkeranjang='$id'");

 ?>