<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>
<!doctype html>
<html lang=en>
<head>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name=viewport />
<meta name=viewport content="width=device-width" />
<link href=../assets/css/bootstrap.min.css rel=stylesheet />
<link href=../assets/css/animate.min.css rel="stylesheet"/>
<link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
<link href=../assets/css/demo.css rel=stylesheet />
<link href=http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css rel=stylesheet>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel=stylesheet type=text/css>
<link href=../assets/css/pe-icon-7-stroke.css rel=stylesheet />
<script type=text/javascript src=http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js></script>
</head>
<body>
<br>
<div class=content>
<div class=container-fluid>
<div class=row>
<div class=col-md-8>
<div class=card>
<div class=header>
</div>
<div class=content>
<div class=form-section style=overflow:auto>
<center><small><?php echo $set['fin1']?><br></small></center>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js></script>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js></script>
<?php include "../dbconnect.php";?>
<script type=text/javascript>$(document).ready(function(){$("#golek").keyup(function(){var a=$("#golek").val();if(a!=""){$("#jesil").html("<img width=300px src='loading.gif'/>");$.ajax({type:"post",url:"bari.php",data:"r="+a,success:function(b){$("#jesil").html(b)}})}})});</script>
<br><br><div style=padding:20px><input style="width:100%;border:1px solid #09c;padding:10px;border-radius:5px" autocomplete=off type=text name=golek id=golek class=form-control placeholder="<?php echo $set['fin2']?>"/>
<div style=width:100%;border:0;border-radius:40px;color:#796d6d id=jesil></div></div><br><br>
</div>
</div>
</div>
</div>
<div class=col-md-4>
<div class="card card-user" style=padding:0;margin:0><br><center>
<?php echo $set['fin3']?>
</center></small>
<div class=content style=padding:0;margin:0>
<table width="100%" style="color:#000;font-family:monospace;font-size:14px">
<thead>
<tr width="100%" style="border-top:1px solid #000;border-right:0;border-left:0;border-bottom:1px solid #000;border-style:dashed;font-family:monospace;padding:3px;font-weight:normal">
<th width="50%" style="padding:3px"><?php echo $set['fin4']?></th>
<th width="20%" style="padding:3px"><?php echo $set['fin5']?></th>
<th width="30%" style="padding-top:3px"><center><?php echo $set['fin6']?></center></th>
</tr>
<?php 
$query = "SELECT * FROM sewa WHERE YEAR(tglkembali) = YEAR(NOW( )) AND MONTH(tglkembali) = MONTH(NOW( )) AND DAY(tglkembali) = DAY(NOW( )) and status='active' order by tglkembali ASC";
$select = mysqli_query($mysqli,$query);
while ($result = mysqli_fetch_array($select)) {
   ?>
<tr>
<td ><small><center><?php echo $result['namausers']; ?></center></small></td>
<td ><center><?php echo $result['contact']; ?></center></td>
<td ><center><?php echo $result['kodesewa']; ?></center></td>
</tr>
<?php } ?>
</thead>
</table>
</div>
<hr>
<div class=text-center>
<small><?php echo $set['fin7']?></small>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
<script src=../assets/js/jquery.3.2.1.min.js type=text/javascript></script>
<script src=../assets/js/bootstrap.min.js type=text/javascript></script>
<script src=../assets/js/chartist.min.js></script>
<script src=../assets/js/bootstrap-notify.js></script>
<script type=text/javascript src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>
<script src=../assets/js/demo.js></script>
</html>