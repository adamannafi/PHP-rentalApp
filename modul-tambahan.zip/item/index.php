<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	alert("sesseion expired!! silahkan login kembali");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
?>

<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body>
<?php
//including the database connection file
include_once("../dbconnect.php");
$result = mysqli_query($mysqli, "SELECT * FROM product ORDER BY idproduct DESC");
?>
<div class="wrapper">
 
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><?php echo $set['item1']?></h4>
                                <p class="category"><?php echo $set['item2']?></p>
                            </div><br><br>
							<table width="100%;background:#fff;padding:10px;"><tr>
<td width="40%"style="padding:10px;border-right:none;background:none">
<small>
<?php echo $set['item3']?></small></td>
<td width="20%"style="border-right:none;background:none">
<center><div class="btn btn-info btn-lg" id="myBtn" style="padding:10px;background: linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;border:none;border-radius:20px;width:80%"><?php echo $set['item4']?></div>
</center></td>
<td width="20%"style="border-right:none;background:none">
<center><a href="category/index.php" class="btn btn-info btn-lg" style="padding:10px;background: linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;border:none;border-radius:20px;color:#fff;width:80%"><?php echo $set['item5']?></a>
</center></td>
<td width="20%"style="border-right:none;background:none">
<center><a href="print.php" class="btn btn-info btn-lg" style="padding:10px;background: linear-gradient(87deg, #49eca1 0, #5b966d 100%) !important;border:none;border-radius:20px;color:#fff;width:80%" target="blank"><?php echo $set['item6']?></a>
</center></td>
</tr></table><br>
<div class="content table-responsive table-full-width">                    
<table class="table table-bordered" style="font-size:12px;" id="dataTable" width="100%" cellspacing="0">
<thead>
<th>No.</th>
<th ><?php echo $set['item7']?></th>
		<th ><?php echo $set['item8']?></th>
		<th ><?php echo $set['item9']?></th>
		<th ><?php echo $set['item10']?></th>	
		<th ><?php echo $set['item11']?></th>
		<th >Status</th>		
<th >navigation</th>
</thead>
<?php 
$i = 1;
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		?>
<td width="10%"style="">
<?php
echo $i;
$i++;
?>
</td><?php
		echo"<td width='10%'>";?>
	<?php 
if (empty($res['picture'])) { ?>
<img src="../nopic.png" style="width:100px"/>
<?php }else{ ?>
		<?php
	if($res['picture']=='0')
      {
		echo "<img width=100px src=../nopic.png> </img>";
		  }
		  else {?>
<img src="../fotobarang/<?php echo $res['picture'];?>" style="width:100px"/>
<?php }}
		echo"</td>";
		echo "<td width=15%><b>".$res['namaproduct']."<br>".$set['item12'].": ".$res['kodebarang']."  <br>Input on: ".$res['created']."<br><br>".$set['item13'].": ".$res['pemilik']."<br>Contact: ".$res['contact']." <br>".$set['item14'].": ".$res['brand']."</td>";
		echo "<td width=5%>".$res['detail']."</td>";	
		echo "<td width=15%>".$res['id_kategori']."</td>";
		
$num_rows = $res['hargasewa']; 
$perawat = number_format($num_rows,0,",",".");
		echo "<td width=15%>".$info['currency']." ".$perawat."</td>";
		echo "<td width=15%>".$res['status']."</td>";
		echo "<td width=5%>";
 echo "<a style=padding:5px;color:#fff href=delete.php?idproduct=$res[idproduct] onClick=\"return confirm('Are you sure you want to delete?')\"><img src=../delete.png width=25px />Delete</a>";	
echo"<br><br>
		<a style=padding:5px;color:#fff; href=update.php?idproduct=$res[idproduct]><img src=edit.png width=25px /></a>"; 
		echo"</td>";
		echo "</tr>";	
		
	}
	?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                 

                </div>
            </div>
        </div>
</div>
  <link href="../assets/bootstrap.min.css" rel="stylesheet">

    <link href="../assets/datatables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript-->
    <script src="../assets/jquery.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../assets/jquery.datatables.min.js"></script>

    <script src="../assets/datatables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
	<style>
.jodal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 9999; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #fff;
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  -webkit-animation-name: fadeIn; /* Fade in the background */
  -webkit-animation-duration: 0.4s;
  animation-name: fadeIn;
  animation-duration: 0.4s
}

/* Modal Content */
.jodal-content {
  position: relative;
  bottom: 0;
  background-color: #fff;
  width: 100%;
  -webkit-animation-name: slideIn;
  -webkit-animation-duration: 0.4s;
  animation-name: slideIn;
  animation-duration: 0.4s
}

/* The Close Button */
.close {
color: red;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.jodal-header {
  padding: 2px 16px;
  background-color: #fff;
  color: #949292;
}

.jodal-body {padding: 2px 16px;}

.jodal-footer {
  padding: 2px 16px;
  background-color: #fff;
  color: white;
}

/* Add Animation */
@-webkit-keyframes slideIn {
  from {bottom: -300px; opacity: 0} 
  to {bottom: 0; opacity: 1}
}

@keyframes slideIn {
  from {bottom: -300px; opacity: 0}
  to {bottom: 0; opacity: 1}
}

@-webkit-keyframes fadeIn {
  from {opacity: 0} 
  to {opacity: 1}
}

@keyframes fadeIn {
  from {opacity: 0} 
  to {opacity: 1}
}
</style>
<div id="myJodal" class="jodal">

  <!-- Modal content -->
  <div class="jodal-content">
    <div class="jodal-header">
      <span class="close" style="margin: 10px;">&times;</span><br>
      <h2><?php echo $set['item15']?> </h2>
    </div> 
    <div class="jodal-body" style="padding:10px">
     <form id="form"action="add.php" enctype="multipart/form-data"  method="post" name="postform">

<table style="width:100%;">
  <tr style="padding:10px">
    <th colspan="4" style="padding:10px"></th>
  </tr>
  <tr>
 <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item12']?><br><small>Automatic/Custom for barcode</small></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding: 10px;width:100%;border: 1px solid #09c;border-radius: 25px;"type="text" placeholder="<?php echo $set['item12']?> for Barcode" name="kodebarang" value="RPOS-<?php
function resi(){
$gpass=NULL;
$n = 16; // jumlah karakter yang akan di bentuk.
$chr = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
for($i=0;$i<$n;$i++){
$rIdx = rand(1,strlen($chr));
$gpass .=substr($chr,$rIdx,1);
}return $gpass;};echo resi();?>"></td>
  
<td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item10']?></td>
<td style="padding: 10px;border-bottom: 1px solid grey;">
 <select class="form-control" style="border:1px solid #09c;border-radius:25px;width:100%" name="id_kategori" required="required"> 
            <option style="color:grey" value="" ><?php echo $set['item16']?></option>
	    <?php
		$get=mysqli_query($mysqli, "SELECT * FROM kategori");
            while($jim = mysqli_fetch_assoc($get))
            {
            ?>
            <option name="id_kategori" style="color:grey" value="<?php echo $jim['namakategori'];?>" ><?php echo $jim['namakategori']; ?></option>
            <?php
            }               
        ?>
		</select><br>

</td>  </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item8']?></td>
    <td colspan="3"style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" placeholder="Item name or Title item" name="namaproduct"required="required"></td>

  </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item13']?> <small>(<?php echo $set['item17']?>)</small></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" placeholder="Owner Name" name="pemilik"></td>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item18']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="number" placeholder="Phone Number" name="contact"></td>
  </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item19']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" placeholder="Brand or Sponsors" name="brand"required="required"></td>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item11']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="number" placeholder="Daily Prices" name="hargasewa"required="required"></td>
  </tr>
  <tr>
    <td colspan="2"style="padding:10px;border-bottom: 1px solid grey;font-size:12px;">
	<div style="position:relative;color:#444;padding:15px;font-weight:bold"><center style="font-size:11px"><?php echo $set['item7']?></div>
<label style="padding:10px;background: #f27a05;color: #fff;border: none;width:100%" class="btn btn-default btn-sm center-block btn-file">
  <i class="fa fa-camera fa-2x" aria-hidden="true"> <small style="font-size:12px;font-family:segoe UI"><b>Upload <?php echo $set['item7']?></b></small></i>
  <input type="file" id="fileInput"  class="upload-file" name="picture" onchange="readURL(this);" style="display: none;" required='required' accept="image/*;capture=camera" >
</label>
<img id="blah" style="width:80%;height:auto" />
<script>
     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<br><br></center>
	<script src="//cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
	 <textarea name="detail" width="100%" height="100px" style="width:100%;height:150px" placeholder="<?php echo $set['item20']?>"></textarea><br>
        <script>
            CKEDITOR.replace( 'text_editor' );
        </script>
</td>
    <td colspan="2" style="padding: 10px;border-bottom: 1px solid grey;">

<center>
	<small>** <?php echo $set['item21']?><small> 
<br><br>
<input type="hidden" name="created"value="<?php echo date('d-m-Y H:i:s'); ?>"/>

<div class="jodal-footer">
<button type="submit" name="submit" class="btn btn-info btn-lg" style="z-index:9999;width:80%;height:70px" data-color="blue"><?php echo $set['item22']?><br></button><br>
</center>
<br><br><br>
	</td>
    
</tr>
</table>
<br>
</div>

	</form>
    </div>
  </div>

</div>

<script>
// Get the modal
var jodal = document.getElementById("myJodal");

// Get the button that opens the modal
var div = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
div.onclick = function() {
  jodal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  jodal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    jodal.style.display = "none";
  }
}
</script>
</html>
<style>#loading{display:block;position:fixed;z-index:9999;top:0;left:0;z-index:99999;width:100vw;height:100vh;background-image:url("hourglass.svg");background-repeat:no-repeat;background-position:center}</style>
<div id="loading" style="display:none"></div>
<script type="text/javascript">function showDiv(){div=document.getElementById("loading");div.style.display="block"}</script>
