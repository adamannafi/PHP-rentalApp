<?php
session_start();
include_once '../dbconnect.php';
if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
	$kang=mysqli_query($mysqli, "SELECT * from info where idinfo='1'");
	$info=mysqli_fetch_array($kang);
	$nas=mysqli_query($mysqli, "SELECT * from settinglang where status='Default'");
	$lang=mysqli_fetch_array($nas);
	$activelang=$lang['nameset'];
	$sd=mysqli_query($mysqli, "SELECT * from language where namelang='$activelang'");
	$set=mysqli_fetch_array($sd);
$idproduct = $_GET['idproduct'];
$row=mysqli_fetch_array(mysqli_query($mysqli, "select * from product where idproduct='$idproduct'"));

if(isset($_POST['post']))
{
$created=date('d-m-Y h:i:s');
$namaproduct = $_POST['namaproduct'];
$kodebar = $_POST['kodebarang'];
$brand = $_POST['brand'];
$detail = $_POST['detail'];
$pemilik = $_POST['pemilik'];
$hargasewa = $_POST['hargasewa'];
$contact = $_POST['contact'];
$id_kat = $_POST['id_kategori'];
$stock = $_POST['stock'];
$idproduct = $_POST['idproduct'];

	$kodebar = trim($kodebar);
	$namaproduct = trim($namaproduct);
	
	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['sicture'];
	}else{
		$picture=$_FILES['picture']['name'];
		//definisikan variabel file dan kendaraan file
		$uploaddir='../fotobarang/';
		$kendaraanfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file($_FILES['picture']['tmp_name'],$kendaraanfile);
	}
	
$query=mysqli_query($mysqli, "UPDATE `product` SET `namaproduct` = '$namaproduct', `stock` = '$stock', `created` = '$created', `brand` = '$brand', `detail` = '$detail', `picture` = '$picture', `hargasewa` = '$hargasewa', `pemilik` = '$pemilik', `contact` = '$contact', `id_kategori` = '$id_kat' WHERE `product`.`idproduct` = '$idproduct';");
if($query){
		?>
	<center><script>document.location.href="index.php";</script>
</center>
		<?php
	}else{
		echo mysql_query();
	}
	

}else{
	unset($_POST['submit']);
}
?>
	<meta charset="utf-8" />
	<html>
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo PuUSD se, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	
</head>
<body style="padding:25px;"><center>
<div class="wrapper">
 
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
						<a href="index.php" style="position:relative;left:0;float: left;color:red" onclick="javascript:showDiv();"><img src="../backblack.png"width="25px"/> Back and Cancel</i></a><br>
                                <h4 class="title">Editing Item</h4>
                              </div><br><br>
                            <div class="content table-responsive table-full-width">
                                

     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data"  method="post" name="postform">

<table style="width:100%;">
  <tr style="padding:10px">
    <th colspan="4" style="padding:10px"></th>
  </tr>
  <tr>
 <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item12']?><br><small>Automatic/Custom</small></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding: 10px;width:100%;border: 1px solid #09c;border-radius: 25px;"type="text" placeholder="Item Code for Barcode" name="kodebarang" value="<?php echo $row['kodebarang'];?>" disabled></td>
  
  <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item10']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;">
 <select class="form-control" style="border:1px solid #09c;border-radius:25px;width:100%" name="id_kategori" required="required"> 
        <option name="id_kategori" style="color:grey" value="" ><?php echo $set['item16']?></option>
	    <?php
		$get=mysqli_query($mysqli, "SELECT * FROM kategori");
            while($jim = mysqli_fetch_assoc($get))
            {
            ?>
            <option name="id_kategori" style="color:grey" value="<?php echo $jim['namakategori'];?>" ><?php echo $jim['namakategori']; ?></option>
            <?php
            }               
        ?>
		</select><br>

</td>  </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item8']?></td>
    <td colspan="3" style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" value="<?php echo $row['namaproduct'];?>" name="namaproduct"required="required"></td>
     </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item13']?> <small>(<?php echo $set['item17']?>)</small></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" value="<?php echo $row['pemilik'];?>" name="pemilik"></td>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item18']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" value="<?php echo $row['contact'];?>" name="contact"></td>
  </tr>
  <tr>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item19']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="text" value="<?php echo $row['brand'];?>" name="brand"required="required"></td>
    <td style="padding:10px;border-bottom: 1px solid grey;font-size:12px;"><?php echo $set['item11']?></td>
    <td style="padding: 10px;border-bottom: 1px solid grey;"><input style="padding:10px;border:1px solid #09c;border-radius:25px;width:100%"type="number" value="<?php echo $row['hargasewa'];?>" name="hargasewa"required="required"></td>
  </tr>
  <tr>
    <td colspan="2"style="padding:10px;border-bottom: 1px solid grey;font-size:12px;">
	<div style="position:relative;color:#444;padding:15px;font-weight:bold"><center style="font-size:11px"><?php echo $set['item7']?></div>
  <label style="font-size:12px;font-family:segoe UI"><b>Upload <?php echo $set['item7']?></b></label>
	<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="file" name="picture" size="999999">
	<input style="border:1px solid grey;padding:10px;width:100%" ID="FileUpload1" onchange="IsFileSelected()" type="hidden" name="sicture" value="<?php echo $row['picture'];?>">


<br><br></center>
	<script src="//cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
	 <textarea name="detail" width="100%" height="100px" style="width:100%;height:150px" value="<?php echo $row['detail'];?>"><?php echo $row['detail'];?></textarea><br>
        <script>
            CKEDITOR.replace( 'text_editor' );
        </script>
</td>
    <td colspan="2" style="padding: 10px;border-bottom: 1px solid grey;">

<center>
	<small>** <?php echo $set['item21']?><small> 
<br><br>
<input type="hidden" name="idproduct"value="<?php echo $row['idproduct']; ?>"/>

<button type="submit" name="post" class="btn btn-info btn-lg" style="z-index:9999;width:80%;height:70px" data-color="blue"><?php echo $set['item22']?></button><br>
</center>
<br><br><br>
	</td>
    
</tr>
</table>
<br>

<br><br><br>
	</form>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> Update Product
                </p>
            </div>
        </footer>


</div>
</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo puUSD se -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</center>

</html>
