<?php
//including the database connection file
include("../../dbconnect.php");

//getting id of the data from url
$idkatego = $_GET['idkatego'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM kategori WHERE idkatego='$idkatego'");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

