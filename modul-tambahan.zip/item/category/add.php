<?php
session_start();
include_once '../../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
?>
<?php

if(isset($_POST['submit']))
{
$created=date('d-m-Y H:i:s');

$namakategori = $_POST['namakategori'];

	// email exist or not
	$query = "SELECT * FROM kategori WHERE namakategori='$namakategori'";
	$result = mysqli_query($mysqli, $query);
	
	$count = mysqli_num_rows($result); // if email not found then register
	
	
	if($count == 0){

		if(mysqli_query($mysqli, "INSERT INTO `kategori` (`idkatego`, `namakategori`, `created`, `counter`) VALUES (NULL, '$namakategori', '$created', '0');"))
		{
			?>
	<script>document.location.href="index.php";</script>
			<?php
		}
		else
		{
			?><div style="color: #F0;">Busy Server</div><?php
		}		
	}
	else{
			?><div style="color: #F0;">Category has ben registered</div><?php
	}
	
}
?>