<?php
session_start();
include_once '../dbconnect.php';

if(!isset($_SESSION['mitra']))
{
	header("Location: ../index.php");
}
$res=mysqli_query($mysqli, "SELECT * FROM mitra WHERE id_mitra=".$_SESSION['mitra']);
$rows=mysqli_fetch_array($res);
?>
<?php

if(isset($_POST['submit']))
{
$created=date('d-m-Y h:i:s');
$namaproduct = $_POST['namaproduct'];
$kodebar = $_POST['kodebarang'];
$brand = $_POST['brand'];
$detail = $_POST['detail'];
$pemilik = $_POST['pemilik'];
$hargasewa = $_POST['hargasewa'];
$contact = $_POST['contact'];
$id_kat = $_POST['id_kategori'];
$stock = $_POST['stock'];

	$kodebar = trim($kodebar);
	$namaproduct = trim($namaproduct);
	// email exist or not
	$query = "SELECT * FROM product WHERE namaproduct='$namaproduct'";
	$result = mysqli_query($mysqli, $query);
	$count = mysqli_num_rows($result); // if email not found then register
	
	if($count == 0){
		
	$picture = $_POST['picture'];
	if(empty($_FILES['picture']['name'])){
		$picture=$_POST['picture'];
	}else{		
		$pipis=$_FILES['picture']['name'];
		$picture=str_replace(" ", "", $pipis);
		//definisikan variabel file dan kendaraan file
		$uploaddir='../fotobarang/';
		$kendaraanfile=$uploaddir.$picture;
		//periksa jika proses upload berjalan sukses
		$upload=move_uploaded_file(str_replace(" ", "", $_FILES['picture']['tmp_name']),$kendaraanfile);
	}
	
		if(mysqli_query($mysqli, "INSERT INTO `product` (`idproduct`, `namaproduct`, `stock`, `created`, `kodebarang`, `brand`, `detail`, `picture`, `batassewa`, `hargasewa`, `pemilik`, `contact`, `id_kategori`, `status`, `kodesewa`, `tglsewa`, `tglkembali`) VALUES (NULL, '$namaproduct', '$stock', '$created', '$kodebar', '$brand', '$detail', '$picture', '-', '$hargasewa', '$pemilik', '$contact', '$id_kat', 'available', '0', '0', '0');"))
		{
			?>
	<script>document.location.href="index.php";</script>
			<?php
		}
		else
		{
			?><div style="color: #F0;">Busy Server</div><?php
		}		
	}
	else{
			?><div style="color: #F0;">Nama barang sudah terdaftar</div><?php
	}
	
}
?>