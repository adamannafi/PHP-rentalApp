<?php
//index.php




?>
<html>
 <head>
  <link rel="stylesheet" href="fullcalendar.css" />
  <link rel="stylesheet" href="calendarboot.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
  <script>
   
  $(document).ready(function() {
   var calendar = $('#calendar').fullCalendar({
    editable:false,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month,agendaWeek,agendaDay'
    },
    events: 'load.php',
    selectable:false,
    selectHelper:true,
    select: function(start, end, allDay)
    {

    },

   });
  });
   
  </script>
 </head>
 <body>
  <div class="container">
   <div id="calendar"></div>
  </div>
  <center><b>Click to Show Item Rent Calendar Monthly, Week, Or Day</b></center>
 </body><br><br>
</html>
