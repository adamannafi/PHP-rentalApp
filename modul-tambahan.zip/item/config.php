<?php
$mysqli = mysqli_connect("localhost","inspekfm_ibase","ogsIIUxh^BOi","inspekfm_ibase");
?>