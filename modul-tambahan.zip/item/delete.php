<?php
//including the database connection file
include("../dbconnect.php");

//getting id of the data from url
$idproduct = $_GET['idproduct'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM product WHERE idproduct='$idproduct'");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

