<?php
include 'mitra-data.php';
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=mitra-data.xls");
?>