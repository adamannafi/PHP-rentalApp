<?php

//load.php

$connect = new PDO('mysql:host=localhost;dbname=xxDbNamexx', 'xxDbUserxx', 'xxDbPasswordxx');

$data = array();

$query = "SELECT * FROM product where status='rented' and kodesewa !='book' ORDER BY idproduct";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

foreach($result as $row)
{
 $data[] = array(
  'id'   => $row["idproduct"],
  'title'   => $row["namaproduct"],
  'start'   => $row["tglsewa"],
  'end'   => $row["tglkembali"]
 );
}

echo json_encode($data);

?>