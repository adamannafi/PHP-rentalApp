<?php
$connect = mysqli_connect("localhost","sinyonya_mobile","#ka110BB0!pD","sinyonya_mobile");
?>